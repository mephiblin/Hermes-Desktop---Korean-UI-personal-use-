Hermes Desktop Korean source pack — 2026-10-10
Base: official v0.21.6 / 818c13be1dc4fd28987e1e881a9408224afd4535.
Includes the previously retained local media/voice guards needed to reproduce this installation, not just text substitutions.
The patch covers tracked files; source/ also supplies new untracked Korean modules.
Use the exact base tag, inspect the diff and back up source/app before applying. Do not overwrite another Hermes version blindly.
Install repository dependencies at the repository root with npm ci, then apps/desktop: npm run typecheck and npm run pack.
No credentials, user settings, conversations or app binaries are included.
