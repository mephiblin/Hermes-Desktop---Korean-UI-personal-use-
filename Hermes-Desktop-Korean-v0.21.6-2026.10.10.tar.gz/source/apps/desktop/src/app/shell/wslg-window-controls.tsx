import type { CSSProperties, PointerEvent } from 'react'

import { Codicon } from '@/components/ui/codicon'
import { useDesktopCopy } from '@/i18n/local-desktop-copy'
import { cn } from '@/lib/utils'

import { TITLEBAR_HEIGHT } from './titlebar'

interface WslgWindowControlsProps {
  isFullscreen: boolean
  isMaximized: boolean
}

// Full-height caption buttons sized to match the native Windows cluster
// (~46px wide × full titlebar height). `h-full` fills the cluster box, whose
// height is pinned to TITLEBAR_HEIGHT below — NOT var(--titlebar-height), which
// the contrib shell zeroes for content subtrees (controller.tsx), collapsing
// the buttons if inherited.
const buttonClass =
  'grid h-full w-[46px] place-items-center border-0 bg-transparent p-0 text-muted-foreground transition-colors duration-75 select-none [-webkit-app-region:no-drag] focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-ring hover:bg-white/10 hover:text-foreground active:bg-white/15'

// Match the native titlebar tools: stopPropagation (NOT preventDefault) on
// pointerdown. preventDefault on pointerdown suppresses the synthesized click
// under WSLg's XWayland/RAIL compositor, so the buttons render but never fire.
// stopPropagation keeps the drag region from swallowing the press while leaving
// the click intact; keyboard-focus reassertion after maximize is handled on the
// main side in performWindowControl (win.focus()).
const stopTitlebarDrag = (event: PointerEvent<HTMLButtonElement>) => event.stopPropagation()

export function WslgWindowControls({ isFullscreen, isMaximized }: WslgWindowControlsProps) {
  const controls = window.hermesDesktop?.windowControls
  const copy = useDesktopCopy()

  if (!controls || isFullscreen) {
    return null
  }

  // Call the bridge with NO arguments: contextBridge structured-clones every
  // argument into the preload world and a React SyntheticEvent (DOM nodes,
  // nativeEvent, functions) is not cloneable, so `onClick={controls.minimize}`
  // throws "An object could not be cloned" before ipcRenderer.send ever runs
  // and the button silently does nothing.
  return (
    <div
      aria-label={copy('settings.windowControls.group')}
      className="fixed right-0 top-0 z-80 flex items-stretch overflow-hidden bg-(--ui-chat-surface-background) text-[10px]"
      // Pin the real titlebar height: the shared --titlebar-height var is
      // contextually zeroed inside the contrib shell, so read the constant.
      style={{ height: `${TITLEBAR_HEIGHT}px` } as CSSProperties}
    >
      <button
        aria-label={copy('settings.windowControls.minimize')}
        className={buttonClass}
        onClick={() => controls.minimize()}
        onPointerDown={stopTitlebarDrag}
        type="button"
      >
        <Codicon name="chrome-minimize" size={10} />
      </button>
      <button
        aria-label={copy(isMaximized ? 'settings.windowControls.restore' : 'settings.windowControls.maximize')}
        className={buttonClass}
        onClick={() => controls.toggleMaximize()}
        onPointerDown={stopTitlebarDrag}
        type="button"
      >
        <Codicon name={isMaximized ? 'chrome-restore' : 'chrome-maximize'} size={10} />
      </button>
      <button
        aria-label={copy('settings.windowControls.close')}
        className={cn(
          buttonClass,
          'hover:bg-[#c42b1c] hover:text-white active:bg-[#b3271a] active:text-white dark:hover:bg-[#c42b1c]'
        )}
        onClick={() => controls.close()}
        onPointerDown={stopTitlebarDrag}
        type="button"
      >
        <Codicon name="chrome-close" size={10} />
      </button>
    </div>
  )
}
