import { useDesktopCopy } from '@/i18n/local-desktop-copy'

export function EmbedFail({ label }: { label: string }) {
  const copy = useDesktopCopy()

  return (
    <span className="grid min-h-32 w-full place-items-center p-4">
      <span className="text-xs font-medium text-(--ui-red)">{copy('chat.embedLoadFailed', label)}</span>
    </span>
  )
}
