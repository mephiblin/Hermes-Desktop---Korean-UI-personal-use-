'use client'

import { TextMessagePartProvider, useMessagePartText } from '@assistant-ui/react'
import {
  type StreamdownTextComponents,
  StreamdownTextPrimitive,
  type SyntaxHighlighterProps,
  tailBoundedRemend
} from '@assistant-ui/react-streamdown'
import type { code as streamdownCode } from '@streamdown/code'
import { type ComponentProps, isValidElement, memo, type ReactNode, useEffect, useMemo, useState } from 'react'
import { defaultRemarkPlugins } from 'streamdown'

import { ExpandableBlock } from '@/components/chat/expandable-block'
import { PreviewAttachment } from '@/components/chat/preview-attachment'
import { chunkByLines, SyntaxHighlighter } from '@/components/chat/shiki-highlighter'
import { TranscriptVideo } from '@/components/chat/transcript-video'
import { ZoomableImage } from '@/components/chat/zoomable-image'
import { ErrorBoundary } from '@/components/error-boundary'
import { useMediaImage } from '@/hooks/use-media-image'
import { useI18n } from '@/i18n'
import { useDesktopCopy } from '@/i18n/local-desktop-copy'
import { detectArtifact } from '@/lib/artifact-detect'
import { renderMediaTags } from '@/lib/chat-messages/parts'
import { normalizeExternalUrl, openExternalLink, PrettyLink } from '@/lib/external-link'
import { createMemoizedMathPlugin } from '@/lib/katex-memo'
import { parseMarkdownIntoBlocksCached } from '@/lib/markdown-blocks'
import { preprocessMarkdown } from '@/lib/markdown-preprocess'
import {
  downloadGatewayMediaFile,
  isFileMediaPath,
  isMarkdownDocumentPath,
  isRemoteGateway,
  mediaExternalUrl,
  mediaKind,
  mediaName,
  mediaPathFromMarkdownHref,
  resolveMediaPlaybackSrc,
  validImageDimensions
} from '@/lib/media'
import { previewTargetFromMarkdownHref } from '@/lib/preview-targets'
import { remarkSoftBreaks } from '@/lib/remark-soft-breaks'
import { sessionRefFromMarkdownHref } from '@/lib/session-refs'
import { cn } from '@/lib/utils'
import { useForcedTextDirection } from '@/store/text-direction'

import { ArtifactCard } from './artifact-card'
import { SessionRefLink } from './directive-text'
import { detectEmbed, extractAlert, MarkdownAlert, RichCodeBlock, UrlEmbed } from './embeds'
import { ResizableMarkdownTable, ResizableMarkdownTh } from './markdown-table'
import { paragraphPlainText, TranscriptDirectiveLeaf, useResolvedParagraph } from './transcript-directive'

// Math rendering plugin (KaTeX). Configured once at module scope — the
// plugin is stateless beyond its internal cache so re-creating per-render
// would needlessly thrash. We use a memoizing wrapper around rehype-katex
// (see lib/katex-memo.ts) so that during streaming we re-katex only the
// equations whose source actually changed since the last token. With the
// stock @streamdown/math plugin every equation re-renders on every token,
// which throttles UI updates badly for math-heavy responses; the memoized
// plugin keeps the steady-state work proportional to "new equations
// arriving" rather than "equations × tokens-per-second".
//
// `singleDollarTextMath: true` enables `$x^2$` for inline math (de-facto
// LLM convention). The default false-setting only accepts `$$...$$`.
const mathPlugin = createMemoizedMathPlugin({ singleDollarTextMath: true })

// `@streamdown/code` statically imports ALL of shiki (every grammar + theme —
// the single largest chunk in the renderer), so it must never sit on the
// entry graph. Load it on first markdown mount and swap it into the plugin
// table when it lands; until then fenced code renders through the
// `SyntaxHighlighter` override's plain path (same output Shiki's own
// `delay` fallback shows), so nothing flashes or reflows unexpectedly.
type CodePlugin = typeof streamdownCode
let codePluginCache: CodePlugin | null = null

function useCodePlugin(): CodePlugin | null {
  const [plugin, setPlugin] = useState(codePluginCache)

  useEffect(() => {
    if (plugin) {
      return
    }

    let cancelled = false

    void import('@streamdown/code').then(({ code }) => {
      codePluginCache = code

      if (!cancelled) {
        setPlugin(code)
      }
    })

    return () => {
      cancelled = true
    }
  }, [plugin])

  return plugin
}

const REMARK_PLUGINS = [...Object.values(defaultRemarkPlugins), remarkSoftBreaks]

// Replaces Streamdown's `parseIncompleteMarkdown` (full-text remend per
// flush) with a tail-bounded repair. Must stay module-scope so the prop
// identity is stable across renders.
function preprocessWithTailRepair(text: string): string {
  try {
    return tailBoundedRemend(preprocessMarkdown(text))
  } catch {
    return text
  }
}

function useOpenMediaFile(path: string) {
  const [openFailed, setOpenFailed] = useState(false)

  const open = () => {
    if (window.hermesDesktop && isRemoteGateway()) {
      setOpenFailed(false)
      void downloadGatewayMediaFile(path).catch(() => setOpenFailed(true))
    } else {
      openExternalLink(mediaExternalUrl(path))
    }
  }

  return { open, openFailed }
}

function OpenMediaFailedNote({ name }: { name: string }) {
  const copy = useDesktopCopy()

  return (
    <span className="mt-1 block text-xs text-muted-foreground">
      {copy('chat.mediaFetchFailed', name)}
    </span>
  )
}

function OpenMediaButton({ kind, path }: { kind: 'audio' | 'video'; path: string }) {
  const copy = useDesktopCopy()
  const { open, openFailed } = useOpenMediaFile(path)

  return (
    <span className="block">
      <button
        className="mt-2 ref text-xs font-medium text-muted-foreground hover:text-foreground"
        onClick={open}
        type="button"
      >
        {copy('chat.openMediaFile', kind)}
      </button>
      {openFailed && <OpenMediaFailedNote name={mediaName(path)} />}
    </span>
  )
}

function MediaAttachment({ path }: { path: string }) {
  return mediaKind(path) === 'image' ? (
    <MarkdownImage alt={mediaName(path)} src={path} />
  ) : (
    <MediaPlaybackAttachment path={path} />
  )
}

function MediaPlaybackAttachment({ path }: { path: string }) {
  const copy = useDesktopCopy()
  const { t } = useI18n()
  const [src, setSrc] = useState('')
  const [failed, setFailed] = useState(false)
  const { open, openFailed } = useOpenMediaFile(path)
  const kind = mediaKind(path)
  const name = mediaName(path)

  useEffect(() => {
    let cancelled = false
    let objectUrl = ''

    setFailed(false)
    setSrc('')

    if (kind === 'file') {
      setFailed(true)

      return () => {
        cancelled = true
      }
    }

    void resolveMediaPlaybackSrc(path)
      .then(value => {
        if (value.startsWith('blob:')) {
          objectUrl = value
        }

        if (!cancelled) {
          setSrc(value)
        } else if (objectUrl) {
          URL.revokeObjectURL(objectUrl)
        }
      })
      .catch(() => {
        if (!cancelled) {
          setFailed(true)
        }
      })

    return () => {
      cancelled = true

      if (objectUrl) {
        URL.revokeObjectURL(objectUrl)
      }
    }
  }, [kind, path])

  if (kind === 'audio' && src) {
    return (
      <span className="my-3 block max-w-md rounded-xl border border-(--ui-stroke-tertiary) bg-muted/35 p-3">
        <span className="mb-2 block truncate text-xs font-medium text-muted-foreground">{name}</span>
        <audio className="block w-full" controls onError={() => setFailed(true)} preload="metadata" src={src} />
        {failed && <OpenMediaButton kind="audio" path={path} />}
      </span>
    )
  }

  if (kind === 'video' && src) {
    return (
      <span className="my-3 block max-w-2xl rounded-xl border border-(--ui-stroke-tertiary) bg-muted/35 p-3">
        <span className="mb-2 block truncate text-xs font-medium text-muted-foreground">{name}</span>
        <TranscriptVideo
          className="block max-h-112 w-full rounded-lg bg-black"
          controls
          onError={() => setFailed(true)}
          src={src}
        />
        {failed && <OpenMediaButton kind="video" path={path} />}
      </span>
    )
  }

  return (
    <span className="wrap-anywhere">
      <a
        className="ref wrap-anywhere"
        href="#"
        onClick={event => {
          event.preventDefault()
          open()
        }}
      >
        {failed ? copy('chat.openMediaFile', name) : `${t.common.loading} ${name}…`}
      </a>
      {openFailed && <OpenMediaFailedNote name={name} />}
    </span>
  )
}

// Authored labels can be formatted markdown — an inline-code label like
// [`v1.0.1`](url) arrives as a <code> element, not a plain string. Extract
// the text so MarkdownLink can pass it as `fallbackLabel`; dropping it sent
// the link down the title-fetch / URL-slug fallback path instead (#121321).
function childrenToText(children: unknown): string {
  return flattenChildrenToText(children).trim()
}

function flattenChildrenToText(node: unknown): string {
  if (node === null || node === undefined || typeof node === 'boolean') {
    return ''
  }

  if (typeof node === 'string' || typeof node === 'number') {
    return String(node)
  }

  if (Array.isArray(node)) {
    return node.map(flattenChildrenToText).join('')
  }

  if (isValidElement<{ children?: unknown }>(node)) {
    return flattenChildrenToText(node.props.children)
  }

  return ''
}

function MarkdownLink({ children, className, href, ...props }: ComponentProps<'a'>) {
  const mediaPath = mediaPathFromMarkdownHref(href)

  if (mediaPath) {
    // A delivered markdown document is renderable content, not an opaque
    // download: route it to the preview rail (which renders .md with a
    // rendered/source toggle) instead of the download-link fallback that
    // `mediaKind() === 'file'` would produce. (#84951)
    if (isMarkdownDocumentPath(mediaPath)) {
      return <PreviewAttachment target={mediaPath} />
    }

    // Non-media files (PDFs, data files, anything outside MEDIA_BY_EXT):
    // MediaAttachment's kind==='file' branch is a degraded dead-end (bare
    // "Open <name>" anchor). Route through the preview pipeline instead —
    // the same file card + "Open preview" the bare-path markdown-link
    // branch below produces — so MEDIA: uniformly delivers the richest
    // rendering for every file type.
    if (mediaKind(mediaPath) === 'file') {
      return <PreviewAttachment target={mediaPath} />
    }

    return <MediaAttachment path={mediaPath} />
  }

  const previewTarget = previewTargetFromMarkdownHref(href)

  if (previewTarget) {
    return <PreviewAttachment target={previewTarget} />
  }

  const sessionRef = sessionRefFromMarkdownHref(href)

  if (sessionRef) {
    return <SessionRefLink value={sessionRef} />
  }

  const target = href ? normalizeExternalUrl(href) : href

  if (!target || !/^https?:\/\//i.test(target)) {
    // A plain filesystem href (`[report](/home/user/report.md)`, `file://…`,
    // `~/notes.md`, `C:\…`) names a file on the AGENT's machine. A bare
    // anchor is a dead link there — file:// is blocked in the renderer, and
    // on a remote gateway the path isn't even on this disk. Route it through
    // the preview pipeline instead: normalizeOrLocalPreviewTarget resolves at
    // VIEW time against the session's backend (local reads the file directly;
    // remote fetches it over the authenticated /api/fs bridge), so the same
    // transcript works from every machine that opens it. Media extensions
    // keep their richer inline player.
    const fileHref = href && !href.startsWith('#') && isFileMediaPath(href) ? href : null

    if (fileHref) {
      return mediaKind(fileHref) === 'file' ? (
        <PreviewAttachment target={fileHref} />
      ) : (
        <MediaAttachment path={fileHref} />
      )
    }

    return (
      <a
        className={cn('ref wrap-anywhere', className)}
        href={href}
        rel="noopener noreferrer"
        target="_blank"
        {...props}
      >
        {children}
      </a>
    )
  }

  const text = childrenToText(children)

  // Bare autolink → inline rich embed when a provider matches. Labeled links
  // (`[watch](url)`) stay plain. Desktop only (webview / iframe renderers).
  if (window.hermesDesktop && text && normalizeExternalUrl(text) === target) {
    const embed = detectEmbed(target)

    if (embed) {
      return <UrlEmbed descriptor={embed} />
    }
  }

  // Always pass the link's own text as the fallback label so a bare URL stays
  // fully visible (#121007): previously this was `undefined` when the child
  // text matched the target URL (the bare-autolink case), so PrettyLink fell
  // through to urlSlugTitleLabel — a host-only label like `ncpssd.org` with
  // the address readable only via hover/inspect. The full URL is the label the
  // sender actually wrote into the chat. Labeled links are unchanged: their
  // authored label already wins display by design.
  const fallbackLabel = text || undefined

  return (
    <PrettyLink className={cn('wrap-anywhere', className)} fallbackLabel={fallbackLabel} href={target} {...props} />
  )
}

// Generated/inline media often arrives as image markdown — `![clip](clip.mp4)`.
// A raw <img> with a video/audio source renders a broken-image icon (the file is
// valid, the browser just can't paint it as an image), so route those sources to
// MediaAttachment, which picks the right <video>/<audio> element (streaming
// protocol + open-externally fallback) by media kind. Detection is
// extension-based via mediaKind(); an extension-less/data/blob video URL still
// resolves to 'file' and falls through to the image path as before.
//
// This is split from the image path because that path is built on hooks: a
// conditional return inside it would have to sit after every hook call, which
// would still fire an image resolve for media we never render as an image.
export function MarkdownImage(props: ComponentProps<'img'>) {
  const rawSrc = typeof props.src === 'string' ? props.src : ''
  const kind = rawSrc ? mediaKind(rawSrc) : 'file'

  if (kind === 'video' || kind === 'audio') {
    return <MediaAttachment path={rawSrc} />
  }

  return <MarkdownImageContent {...props} />
}

// A cold frame is ~4:3 because that is the envelope an image can occupy here
// (--image-preview-max-width x --image-preview-height): every shape, portrait
// included, fits at the size it would have without a reserved frame. A 16:9
// box shrank every narrower image (a 1080x1920 portrait to 172x306). Warm
// mounts use the measured size instead.
const COLD_IMAGE_RATIO = 4 / 3

function MarkdownImageContent({
  className,
  src,
  alt,
  width,
  height,
  onLoad,
  onError,
  style,
  ...props
}: ComponentProps<'img'>) {
  const copy = useDesktopCopy()
  const { t } = useI18n()
  const rawSrc = typeof src === 'string' ? src : ''
  const image = useMediaImage(rawSrc, COLD_IMAGE_RATIO, validImageDimensions(width, height))
  const { open, openFailed } = useOpenMediaFile(rawSrc)
  const name = mediaName(rawSrc || String(alt || 'image'))

  if (!rawSrc) {
    return null
  }

  // A broken link has nothing to reserve space for: one line, not an empty
  // frame. The one-time shift on error is the lesser cost.
  if (image.failed) {
    return (
      <span className="my-2 block text-sm text-muted-foreground" data-slot="aui_markdown-image">
        {copy('chat.imageLoadFailed', name)}{' '}
        <button className="ref font-medium text-foreground" onClick={open} type="button">
          {t.desktop.openImage}
        </button>
        {openFailed && <OpenMediaFailedNote name={name} />}
      </span>
    )
  }

  // The image keeps its natural size (never upscaled) inside the fixed frame;
  // the w-fit container hugs it so the download button and shadow sit on the
  // image, not on the letterbox. Without a frame (a source that failed last
  // time) it lays out as a plain capped image, like before frames existed.
  const framed = Boolean(image.frameStyle)

  return (
    <span className="relative my-2 block max-w-full" data-slot="aui_markdown-image" style={image.frameStyle}>
      {image.src ? (
        <ZoomableImage
          {...props}
          alt={alt}
          className={cn(
            'm-0 block h-auto w-auto max-w-full rounded-lg object-scale-down shadow-[0_0.0625rem_0.125rem_color-mix(in_srgb,#000_4%,transparent),0_0.625rem_1.5rem_color-mix(in_srgb,#000_5%,transparent)]',
            framed ? 'max-h-full' : 'max-h-(--image-preview-height)',
            className
          )}
          containerClassName={
            framed
              ? 'absolute left-0 top-0 block h-full w-fit'
              : 'block w-fit max-w-[min(100%,var(--image-preview-max-width))]'
          }
          onError={event => {
            image.onError()
            onError?.(event)
          }}
          onLoad={event => {
            image.onLoad(event.currentTarget)
            onLoad?.(event)
          }}
          src={image.src}
          style={style}
        />
      ) : (
        <span className={cn('block overflow-hidden text-sm text-muted-foreground', framed && 'absolute inset-0')}>
          {t.common.loading} {name}…
        </span>
      )}
    </span>
  )
}

interface MarkdownTextSurfaceProps {
  containerClassName?: string
  containerProps?: ComponentProps<'div'>
  defer?: boolean
  /** This text is the model's private scratchpad (reasoning), so nothing in it
   *  may be promoted into app chrome: no artifact cards from fenced blocks (a
   *  draft must not register artifact versions), and no transcript directives
   *  (a directive the model was only reminding itself about would otherwise
   *  mount a live plugin card inside the thinking block). */
  scratchpad?: boolean
  /** Disable artifact-card promotion for fenced blocks (reasoning text — a
   *  model's scratchpad draft must not register artifact versions). */
  disableArtifacts?: boolean
  /** Foreign history must not load images or mount live transcript directives. */
  previewOnly?: boolean
  /** Re-render the direct text nodes of paragraph-level containers (p / li /
   *  td) — a transcript surface styles its own inline tokens (a Bot Mode room's
   *  routed @mentions) without owning the Markdown pipeline. Nested inline
   *  markup and code are left as rendered. */
  decorateText?: (children: ReactNode) => ReactNode
  /** The reader's explicit Text direction (Appearance). Stamped on the root
   *  and on list/quote boxes in place of their `dir="auto"`, so every prose
   *  block follows it; undefined is Auto and leaves the DOM attribute-free. */
  textDirection?: 'ltr' | 'rtl'
}

// Headings shrink to chat scale rather than the prose default (h1≈xl). Kept
// table-driven so adding/tweaking levels is one row.
const HEADING_SIZES: Record<'h1' | 'h2' | 'h3' | 'h4', string> = {
  h1: 'text-[1.25em] tracking-tight',
  h2: 'text-[1.15em] tracking-tight',
  h3: 'text-[1.075em]',
  h4: 'text-[1em]'
}

const MARKDOWN_CONTAINER_CLASS_NAME = cn(
  'aui-md prose w-full min-w-0 max-w-none overflow-hidden text-[length:var(--conversation-text-font-size)] leading-(--dt-line-height) text-foreground',
  'prose-p:leading-(--dt-line-height) prose-li:leading-(--dt-line-height)',
  'prose-headings:text-foreground prose-strong:text-foreground',
  // Typography styles `pre` as a dark slab: light text (`--tw-prose-pre-code`,
  // gray-200) on a dark bg. We strip its bg for our own light code card but its
  // near-white foreground survives — invisible under Shiki's opaque token
  // spans, but it's what un-highlighted text inherits (streaming delay,
  // Suspense fallback, budget-exceeded blocks): unreadable in light mode.
  'prose-pre:text-foreground',
  'prose-a:break-words prose-p:[overflow-wrap:anywhere]',
  'prose-li:marker:text-muted-foreground/70',
  'prose-code:rounded-[0.25rem] prose-code:px-[0.1875rem] prose-code:py-px prose-code:font-mono prose-code:text-[0.9em] prose-code:font-normal prose-code:before:content-none prose-code:after:content-none',
  '[&>*:first-child]:mt-0 [&>*:last-child]:mb-0 [&>*+*]:mt-(--paragraph-gap)'
)

const MAX_MARKDOWN_CHARS = 200_000

function HugeTextFallback({ containerClassName, text }: { containerClassName?: string; text: string }) {
  const chunks = useMemo(() => chunkByLines(text, 200), [text])

  return (
    <div
      className={cn(
        'aui-md w-full max-w-none overflow-hidden rounded-[0.625rem] border border-(--ui-stroke-tertiary) font-mono text-[0.7rem] leading-relaxed text-foreground/90',
        containerClassName
      )}
    >
      <ExpandableBlock className="p-2">
        {chunks.map((chunk, index) => (
          <div
            className="whitespace-pre-wrap wrap-anywhere [content-visibility:auto]"
            key={index}
            style={{ containIntrinsicSize: `auto ${chunk.lines * 16}px` }}
          >
            {chunk.text}
          </div>
        ))}
      </ExpandableBlock>
    </div>
  )
}

/**
 * Paragraph override. Almost always a plain `<p>` — but a paragraph that is
 * exactly one `::name{...}` directive claimed by a plugin renders as that
 * plugin's transcript component instead (`transcript.directives` area). The
 * claim check subscribes to the registry, so hot-loading a plugin upgrades
 * already-rendered directives in place; unclaimed directives stay prose.
 */
function MarkdownParagraph({
  children,
  className,
  scratchpad,
  streaming,
  ...props
}: ComponentProps<'p'> & { scratchpad?: boolean; streaming?: boolean }) {
  const plain = paragraphPlainText(children)
  const resolved = useResolvedParagraph(scratchpad ? null : plain)

  // Vertical rhythm is owned by styles.css (`--paragraph-gap`), which must
  // out-specify Tailwind Typography's `prose` margins — so no `my-*` here.
  const paragraphClass = cn('wrap-anywhere leading-(--dt-line-height)', className)

  // A paragraph that is one directive renders as the card alone; one that
  // ends in a directive renders as its sentence followed by the card.
  if (resolved) {
    return (
      <>
        {resolved.map((segment, index) =>
          segment.kind === 'directive' ? (
            <TranscriptDirectiveLeaf key={index} streaming={streaming} text={segment.source} />
          ) : (
            <p className={paragraphClass} key={index} {...props}>
              {segment.text.trim()}
            </p>
          )
        )}
      </>
    )
  }

  return (
    <p className={paragraphClass} {...props}>
      {children}
    </p>
  )
}

function MarkdownTextSurface({
  containerClassName,
  containerProps,
  decorateText,
  defer,
  disableArtifacts,
  previewOnly,
  scratchpad,
  textDirection
}: MarkdownTextSurfaceProps) {
  const { status, text } = useMessagePartText()
  // List/quote boxes resolve from content under Auto (see the ul/ol/blockquote
  // notes below); an explicit choice replaces that vote rather than nesting it.
  const boxDir = textDirection ?? 'auto'

  const surfaceContainerProps = useMemo(
    () => (textDirection ? { ...containerProps, dir: textDirection } : containerProps),
    [containerProps, textDirection]
  )

  const isStreaming = status.type === 'running'

  // Keep code parsing enabled while streaming so incomplete fenced blocks still
  // render as code cards. The expensive Shiki pass is deferred by
  // `SyntaxHighlighter` below when `isStreaming` is true, and the code plugin
  // itself arrives async (useCodePlugin) so shiki never blocks cold start.
  const code = useCodePlugin()
  const plugins = useMemo(() => (code ? { math: mathPlugin, code } : { math: mathPlugin }), [code])

  const components = useMemo(
    () =>
      ({
        h1: ({ className, ...props }: ComponentProps<'h1'>) => (
          <h1 className={cn('my-1 font-semibold', HEADING_SIZES.h1, className)} {...props} />
        ),
        h2: ({ className, ...props }: ComponentProps<'h2'>) => (
          <h2 className={cn('my-1 font-semibold', HEADING_SIZES.h2, className)} {...props} />
        ),
        h3: ({ className, ...props }: ComponentProps<'h3'>) => (
          <h3 className={cn('my-1 font-semibold', HEADING_SIZES.h3, className)} {...props} />
        ),
        h4: ({ className, ...props }: ComponentProps<'h4'>) => (
          <h4 className={cn('my-1 font-semibold', HEADING_SIZES.h4, className)} {...props} />
        ),
        p: ({ children, ...props }: ComponentProps<'p'>) =>
          previewOnly ? (
            <p {...props}>{decorateText ? decorateText(children) : children}</p>
          ) : (
            <MarkdownParagraph {...props} scratchpad={scratchpad} streaming={isStreaming}>
              {decorateText ? decorateText(children) : children}
            </MarkdownParagraph>
          ),
        a: previewOnly ? ({ children }: ComponentProps<'a'>) => <span>{children}</span> : MarkdownLink,
        // Inline code must not vote when an ancestor resolves `dir="auto"`
        // (HTML's algorithm skips descendants that carry their own dir),
        // mirroring the CSS isolate that already keeps it out of the
        // plaintext scan. Fenced code never reaches this override; it goes
        // through the code plugin's CodeCard path.
        inlineCode: ({ className, ...props }: ComponentProps<'code'>) => (
          <code className={className} dir="ltr" {...props} />
        ),
        // `---` as quiet spacing, not a heavy full-width rule.
        hr: (_props: ComponentProps<'hr'>) => <div aria-hidden className="my-3" />,
        // Lists and blockquotes have chrome that sits *beside* the text
        // (markers, the quote border), and that side is driven by the CSS
        // `direction` of the box, which `unicode-bidi: plaintext` never
        // touches — an RTL list otherwise renders its numbers stranded at
        // the far left. `dir="auto"` lets the browser resolve the box
        // direction from content; the plaintext rules in styles.css keep
        // owning per-line text direction. Inline code carries `dir="ltr"`
        // (see the `code` override) so it doesn't vote here either, same
        // contract as the CSS isolate.
        // A `> [!NOTE]`/`[!WARNING]`/... blockquote renders as a GFM alert
        // callout; everything else stays a plain quote.
        blockquote: ({ children, className, ...props }: ComponentProps<'blockquote'>) => {
          const alert = extractAlert(children)

          if (alert) {
            return <MarkdownAlert type={alert.type}>{alert.body}</MarkdownAlert>
          }

          return (
            <blockquote
              className={cn('border-s-2 border-(--ui-stroke-tertiary) ps-3 text-muted-foreground italic', className)}
              dir={boxDir}
              {...props}
            >
              {children}
            </blockquote>
          )
        },
        ul: ({ className, ...props }: ComponentProps<'ul'>) => (
          <ul className={cn('my-1 gap-0', className)} dir={boxDir} {...props} />
        ),
        ol: ({ className, ...props }: ComponentProps<'ol'>) => (
          <ol className={cn('my-1 gap-0', className)} dir={boxDir} {...props} />
        ),
        li: ({ children, className, ...props }: ComponentProps<'li'>) => (
          <li className={cn('leading-(--dt-line-height)', className)} {...props}>
            {decorateText ? decorateText(children) : children}
          </li>
        ),
        // Columns are drag-resizable; the widths live outside the transcript
        // (see markdown-table-widths.ts) so a new turn or a session switch
        // doesn't undo a resize.
        table: ResizableMarkdownTable,
        thead: ({ className, ...props }: ComponentProps<'thead'>) => (
          <thead className={cn('m-0 bg-muted/35 text-muted-foreground', className)} {...props} />
        ),
        th: ResizableMarkdownTh,
        td: ({ children, className, ...props }: ComponentProps<'td'>) => (
          <td
            className={cn(
              'px-2.5 py-1.5 align-top text-[length:var(--conversation-text-font-size)] leading-snug',
              className
            )}
            {...props}
          >
            {decorateText ? decorateText(children) : children}
          </td>
        ),
        img: previewOnly ? ({ alt }: ComponentProps<'img'>) => <span>{alt}</span> : MarkdownImage,
        // ```mermaid / ```svg fences route to their lazy renderers; substantial
        // html/svg/code fences promote to an artifact card that opens in the
        // right rail; every other language falls back to the Shiki-highlighted
        // code block.
        SyntaxHighlighter: (props: SyntaxHighlighterProps) => {
          const artifact =
            disableArtifacts || previewOnly || scratchpad ? null : detectArtifact(props.language, props.code)

          if (artifact) {
            return <ArtifactCard code={props.code} detection={artifact} streaming={isStreaming} />
          }

          return (
            <RichCodeBlock
              code={props.code}
              fallback={<SyntaxHighlighter {...props} defer={isStreaming} />}
              language={props.language}
              streaming={isStreaming}
            />
          )
        }
      }) as StreamdownTextComponents,
    [boxDir, decorateText, disableArtifacts, isStreaming, previewOnly, scratchpad]
  )

  if (text.length > MAX_MARKDOWN_CHARS) {
    return <HugeTextFallback containerClassName={containerClassName} text={text} />
  }

  return (
    // Last line of defence for the whole markdown surface — assistant answers,
    // reasoning, tool output and user bubbles all render through here.
    //
    // The pipeline is recursive in several places we don't own (parse5 →
    // `hast-util-from-parse5` on raw HTML, `mdast-util-to-hast` on nested
    // block structure), so pathological content can still throw
    // `RangeError: Maximum call stack size exceeded` from inside Streamdown's
    // render. `clampHtmlNestingDepth` removes the reachable cause we found;
    // this catches whatever we haven't. Without it the throw unwinds past
    // MessageRenderBoundary — which deliberately re-throws anything that isn't
    // the transient assistant-ui lookup race — and blanks the entire workspace
    // behind "workspace failed to render", on every reload, because the
    // offending message is replayed from the session each time.
    //
    // Degrading to HugeTextFallback keeps the text readable and the rest of
    // the transcript alive. The error stays latched for this surface: content
    // that overflowed the stack will overflow again, and remounting per token
    // during streaming would cost far more than the plain rendering saves.
    <ErrorBoundary
      fallback={() => <HugeTextFallback containerClassName={containerClassName} text={text} />}
      label="markdown-render"
    >
      <StreamdownTextPrimitive
        components={components}
        containerClassName={cn(MARKDOWN_CONTAINER_CLASS_NAME, containerClassName)}
        containerProps={surfaceContainerProps}
        defer={defer}
        lineNumbers={false}
        mode="streaming"
        // Incomplete-markdown repair runs in preprocessWithTailRepair on the
        // full accumulated text; the built-in tail-bounded remend is disabled
        // because a custom parseMarkdownIntoBlocksFn is supplied, and
        // parseIncompleteMarkdown stays false to avoid a second full-text
        // remend pass.
        parseIncompleteMarkdown={false}
        parseMarkdownIntoBlocksFn={parseMarkdownIntoBlocksCached}
        plugins={plugins}
        preprocess={preprocessWithTailRepair}
        remarkPlugins={REMARK_PLUGINS}
      />
    </ErrorBoundary>
  )
}

interface MarkdownTextContentProps extends MarkdownTextSurfaceProps {
  isRunning: boolean
  text: string
}

/** Render raw assistant-style message text through the complete Desktop text
 * pipeline. `MEDIA:` directives must be transformed before Markdown rendering
 * so the canonical link component can route them to inline players/previews.
 * Fenced blocks stay plain code (`disableArtifacts`): a transcript rendered
 * outside a session — a Bot Mode group room — has no session to own artifact
 * versions. `media={false}` leaves `MEDIA:` lines as prose: media paths resolve
 * against the ACTIVE gateway, so a message written on another machine (a
 * Connections Bot in a cross-machine room) must not have its path read here —
 * that is a broken image at best and a same-path local file at worst. */
export function MessageTextContent({
  decorateText,
  media = true,
  text
}: Pick<MarkdownTextSurfaceProps, 'decorateText'> & { media?: boolean; text: string }) {
  return (
    <MarkdownTextContent
      decorateText={decorateText}
      disableArtifacts
      isRunning={false}
      text={media ? renderMediaTags(text) : text}
    />
  )
}

export function MarkdownTextContent({ isRunning, text, ...surfaceProps }: MarkdownTextContentProps) {
  // No `smooth` on purpose — same as the assistant answer. `TextMessagePartProvider`
  // mints a fresh part object on every `text` change, and useSmooth resets its
  // reveal to empty whenever the part identity changes, so a smoothed reasoning
  // stream re-types from the first character on every delta (the flash). Token-
  // streaming reasoners (R1/Qwen/GLM/Claude thinking) hit it hardest; GPT-5's
  // coarse summary updates too rarely to notice. Plain append matches the answer.
  return (
    <TextMessagePartProvider isRunning={isRunning} text={text}>
      <MarkdownTextSurface defer {...surfaceProps} />
    </TextMessagePartProvider>
  )
}

const MarkdownTextImpl = () => {
  const textDirection = useForcedTextDirection()

  return <MarkdownTextSurface defer textDirection={textDirection} />
}

export const MarkdownText = memo(MarkdownTextImpl)
