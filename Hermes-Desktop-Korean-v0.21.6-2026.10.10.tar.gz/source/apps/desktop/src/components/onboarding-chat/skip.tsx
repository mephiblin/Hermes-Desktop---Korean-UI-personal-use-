import { useStore } from '@nanostores/react'

import { Tip } from '@/components/ui/tooltip'
import { useDesktopCopy } from '@/i18n/local-desktop-copy'
import { $introView } from '@/store/onboarding-intro'

import { skipIntro } from './intro'

export function OnboardingSkip() {
  const copy = useDesktopCopy()
  const intro = useStore($introView) === 'intro'

  if (!intro) {
    return null
  }

  return (
    <Tip label={copy('chat.switchingToDefaultProfile')}>
      <button
        className="ml-auto text-[11px] text-(--ui-text-quaternary) transition-colors hover:text-(--ui-text-secondary)"
        onClick={skipIntro}
        type="button"
      >
        {copy('chat.skipSetup')}
      </button>
    </Tip>
  )
}
