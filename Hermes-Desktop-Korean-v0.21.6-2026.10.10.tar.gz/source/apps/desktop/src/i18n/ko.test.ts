import { describe, expect, it } from 'vitest'

import { TRANSLATIONS } from './catalog'
import { en } from './en'
import { koOverrides } from './ko'
import intentionalEnglish from './ko/intentional-english.json'
import { isSupportedLocaleValue, languageOptions, normalizeLocale } from './languages'
import { resolveTranslations } from './registry'

describe('Korean app locale', () => {
  it('registers Korean and renders localized current-version copy', () => {
    expect(isSupportedLocaleValue('ko')).toBe(true)
    expect(normalizeLocale('ko-KR')).toBe('ko')
    expect(languageOptions()).toContainEqual(expect.objectContaining({
      id: 'ko',
      endonym: '한국어',
      englishName: 'Korean',
      source: 'app'
    }))

    const korean = resolveTranslations('ko')
    const english = TRANSLATIONS.en
    expect(korean.common.save).toBe('저장')
    expect(korean.appTour.sessions.title).not.toBe(english.appTour.sessions.title)
    expect(korean.onboarding.introHi).toBe('안녕하세요, Hermes입니다.')
  })
})

function leaves(value: unknown, path = ''): Array<[string, unknown]> {
  if (value && typeof value === 'object' && !Array.isArray(value)) {
    return Object.entries(value).flatMap(([key, child]) => leaves(child, path ? `${path}.${key}` : key))
  }

  return [[path, value]]
}

const englishLeaves = new Map(leaves(en))
const koreanLeaves = new Map(leaves(koOverrides))

it('supplies every English message in the Korean overlay without silent fallback', () => {
  const missing = [...englishLeaves.keys()].filter(path => !koreanLeaves.has(path))
  expect(missing).toEqual([])

  const mismatched = [...englishLeaves].flatMap(([path, value]) => {
    const translated = koreanLeaves.get(path)
    const kind = (v: unknown) => Array.isArray(v) ? 'array' : typeof v

    return kind(translated) === kind(value) ? [] : [{ path, expected: kind(value), actual: kind(translated) }]
  })

  expect(mismatched).toEqual([])
})

it('preserves visible interpolation arguments and list shapes', () => {
  const problems: string[] = []

  for (const [path, value] of englishLeaves) {
    const translated = koreanLeaves.get(path)

    if (Array.isArray(value)) {
      expect((translated as unknown[]).length, path).toBe(value.length)
    }

    if (typeof value !== 'function' || typeof translated !== 'function') {continue}

    if (path !== 'intro.custom' && translated.length !== value.length) {problems.push(`${path}: function arity ${translated.length} != ${value.length}`)}
    const probes = Array.from({ length: value.length }, (_, index) => `⟦${index}⟧`)
    let original: string

    try { original = JSON.stringify(value(...probes)) } catch { continue }
    const localized = JSON.stringify(translated(...probes))

    for (const probe of probes.filter(probe => original.includes(probe))) {
      // Capability identifiers are dispatched, not displayed, by this message.
      if (path === 'settings.toolsets.webCapabilitySelectedMessage' && probe === probes[1]) {continue}

      if (!localized.includes(probe)) {problems.push(`${path} drops ${probe}`)}
    }
  }

  expect(problems).toEqual([])
})

it('localizes every stock personality greeting and unknown personalities', () => {
  const korean = resolveTranslations('ko')
  const personalities = ['helpful', 'concise', 'technical', 'creative', 'teacher', 'kawaii', 'catgirl', 'pirate', 'shakespeare', 'surfer', 'noir', 'uwu', 'philosopher', 'hype', 'none']

  for (const personality of personalities) {
    expect(korean.intro.stock[personality]).toHaveLength(5)

    for (const body of korean.intro.stock[personality]) {expect(body).toMatch(/[가-힣]/)}
  }

  for (const body of korean.intro.custom('CustomPersona')) {
    expect(body).toContain('CustomPersona')
    expect(body).toMatch(/[가-힣]/)
  }
})

it('permits identical English only for reviewed names, identifiers and formatters', () => {
  const allowed = new Set(intentionalEnglish.map(item => item.path))
  const untranslated: string[] = []

  for (const [path, value] of englishLeaves) {
    const translated = koreanLeaves.get(path)
    let same: boolean

    if (typeof value === 'function' && typeof translated === 'function') {
      const args = Array.from({ length: value.length }, (_, i) => `⟦${i}⟧`)

      try { same = JSON.stringify(value(...args)) === JSON.stringify(translated(...args)) } catch { continue }
    } else {same = JSON.stringify(value) === JSON.stringify(translated)}

    if (same && !allowed.has(path)) {untranslated.push(path)}
  }

  expect(untranslated).toEqual([])
})
