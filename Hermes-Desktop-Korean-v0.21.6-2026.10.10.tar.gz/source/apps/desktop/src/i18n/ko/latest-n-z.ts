import type { TranslationOverrides } from '../define-locale'
import { defineFieldCopy } from '@/app/settings/field-copy'

/** Korean copy for the remaining n–z desktop surfaces. */
export const latestNzKo: TranslationOverrides = {
  sharedMetrics: {
    consentTitle: '사용 통계를 공유할까요?', dialogTitle: '사용 통계',
    consentBody: 'Hermes 사용 방식(세션 길이, 사용한 모델과 도구, 오류 발생 시점)을 집계할 수 있습니다. 메시지, 파일, 경로, 오류 내용은 기록하지 않습니다.',
    whatIsCollected: '집계 항목', collectedActivity: '세션: 길이, 결과, 오류 유형, 하루 활성 시간', collectedModels: '모델: 사용한 모델과 토큰 합계',
    collectedNames: '기능: 사용하거나 끈 내장 도구, 명령, 앱 영역 및 설정', collectedMilestones: '설정: 완료한 단계, 공급자 연결, 스킬·플러그인·작업 수',
    collectedReliability: '앱 상태: 충돌, 시작 및 응답 속도, 업데이트, 메시징 연결', collectedUsage: '에이전트 품질: 편집 누락, 도구 호출 오류, 반복 정체, 작업 비용',
    collectedMachine: '기기: 운영체제, RAM 범위, GPU 유형, Hermes 버전, 로컬 모델 사용 여부',
    sending: '공유를 선택하지 않으면 통계는 이 컴퓨터에만 저장됩니다. 공유 통계는 프로필마다 임의 ID를 사용해 하루 한 번 Nous로 전송됩니다. Hermes 최초 설치 안내 외에는 동의하기 전 통계를 보내지 않습니다.',
    readDocs: '자세한 내용 읽기', share: 'Nous와 공유', local: '이 컴퓨터에 보관', off: '괜찮습니다', saveFailed: '선택 사항을 저장하지 못했습니다.',
    collectLabel: '사용 통계 집계', collectDesc: '수치만 집계하여 이 컴퓨터에 보관합니다. 메시지, 파일, 경로, 오류 내용은 포함하지 않습니다.',
    sendLabel: 'Nous와 사용 통계 공유', sendDesc: '프로필마다 임의 ID를 사용해 하루 한 번 Nous로 통계를 전송합니다. 최초 설치 안내를 제외하면 동의하기 전 통계는 전송하지 않습니다. 동의가 필요합니다.',
    unavailable: '이 설정을 바꾸려면 Hermes 백엔드를 업데이트하세요.', stripBody: '수치만 집계합니다. 메시지나 파일은 포함하지 않습니다.',
    stripReaskBody: '다시 확인합니다. 이전 버전에서는 이 안내를 보기 전에 “괜찮습니다”를 저장할 수 있었습니다.',
    stripChoices: { share: 'Nous와 공유', local: '이 컴퓨터에 보관', off: '괜찮습니다' }, stripDetails: '세부 정보'
  },
  notifications: {
    sharedProfileWarning: '다른 Hermes 설치가 이 프로필을 사용 중입니다. 두 설치가 설정과 데이터를 공유하므로 변경 사항이 충돌할 수 있습니다. 계속하거나 변경하기 전에 다른 설치를 종료하세요.',
    region: '알림', hide: '숨기기', show: '표시',
    more: count => `알림 ${count}개 더`, clearAll: '모두 지우기', dismiss: '알림 닫기', details: '세부 정보', copyDetail: '세부 정보 복사', copyDetailFailed: '알림 세부 정보를 복사하지 못했습니다.',
    compressDeferredDone: '대화 맥락 압축 완료', backendOutOfDateTitle: '백엔드가 오래되었습니다',
    backendOutOfDateMessage: 'Hermes 백엔드가 이 Desktop 빌드보다 오래되어 제대로 작동하지 않을 수 있습니다. 두 버전을 맞추려면 업데이트하세요.',
    desktopOutOfDateTitle: 'Hermes 앱이 오래되었습니다',
    desktopOutOfDateMessage: '이 Hermes 앱이 연결된 백엔드보다 오래되어 제대로 작동하지 않을 수 있습니다. 두 버전을 맞추려면 앱을 업데이트하세요.',
    updateDesktopApp: '앱 업데이트', installMethodUnsupportedTitle: '지원하지 않는 설치 방식', updateHermes: 'Hermes 업데이트', updateReadyTitle: '업데이트 준비 완료',
    updateReadyMessage: count => `새 변경 사항 ${count}개를 사용할 수 있습니다.`, updateReadyMessageUnknown: '새 업데이트를 사용할 수 있습니다.',
    updateReadyMessageAppInstaller: '새 Hermes 버전을 사용할 수 있습니다. 지금 업데이트하면 Windows가 설치를 마칩니다.', seeWhatsNew: '새로운 기능 보기',
    mcp: {
      needsAuthTitle: 'MCP 서버에 다시 인증해야 합니다', needsAuthMessage: name => `${name} MCP에 다시 인증해야 합니다.`,
      errorTitle: 'MCP 서버에 연결할 수 없습니다', errorMessage: name => `${name} MCP 상태 확인에 실패했습니다.`, signIn: '로그인', view: '보기', disable: '사용 중지',
      disabledMessage: name => `${name} MCP을 사용 중지했습니다. 기능 → MCP에서 언제든 다시 켤 수 있습니다.`, disableFailed: name => `${name} MCP을 사용 중지하지 못했습니다.`
    },
    errors: {
      elevenLabsNeedsKey: '음성 입력을 사용하려면 ElevenLabs 키가 필요합니다. 설정 → 키에서 추가하세요.',
      elevenLabsRejectedKey: 'ElevenLabs에서 API 키를 승인하지 않았습니다. 설정 → 키에서 키를 바꾼 뒤 다시 시도하세요.',
      diskFull: '디스크 공간이 부족합니다. 공간을 확보한 뒤 다시 시도하세요.', storageFailure: 'Hermes 데이터 폴더에 저장하지 못했습니다. 유지 관리에서 확인하고 복구하세요.',
      gatewayAuthFailed: '이 Hermes에서 저장된 로그인 정보를 더 이상 사용할 수 없습니다. 게이트웨이를 열어 다시 로그인하거나 새 액세스 토큰을 붙여넣은 뒤 다시 시도하세요.',
      methodNotAllowed: 'Hermes 백그라운드 서비스와 앱의 버전이 맞지 않습니다. 업데이트 후 발생했을 수 있습니다. 서비스를 다시 시작해 해결하세요.',
      microphonePermission: '마이크 권한이 거부되었습니다.', openaiRejectedApiKey: 'OpenAI에서 API 키를 승인하지 않았습니다. 설정 → 키에서 키를 바꾼 뒤 다시 시도하세요.',
      openaiTtsNeedsKey: '음성을 사용하려면 OpenAI 키가 필요합니다. 설정 → 키에서 추가하세요.',
      codeSkewRestartRequired: 'Hermes가 업데이트되었지만 이전 버전이 계속 실행 중입니다. 업데이트를 마치려면 다시 시작하세요.',
      rpcOutOfSync: '앱과 백엔드의 버전이 다릅니다. 둘 다 업데이트하세요.', restartHermesFailed: 'Hermes를 다시 시작하지 못했습니다.'
    },
    actions: { restartHermes: 'Hermes 다시 시작', openKeys: '키 열기', openGateways: '게이트웨이 열기', openMaintenance: '유지 관리 열기' },
    voice: {
      configureSpeechToText: '음성 모드를 사용하려면 음성 인식을 설정하세요.', couldNotStartSession: '음성 세션을 시작하지 못했습니다.',
      microphoneAccessDenied: '마이크 접근이 거부되었습니다.', microphoneConstraintsUnsupported: '이 기기는 마이크 설정 조건을 지원하지 않습니다.', microphoneFailed: '마이크 오류',
      microphoneInUse: '다른 앱에서 마이크를 사용 중입니다.', microphonePermissionDenied: '마이크 권한이 거부되었습니다.', microphoneStartFailed: '마이크 녹음을 시작하지 못했습니다.',
      microphoneUnsupported: '이 런타임은 마이크 녹음을 지원하지 않습니다.', noMicrophone: '마이크를 찾지 못했습니다.', noSpeechDetected: '음성이 감지되지 않았습니다.',
      playbackFailed: '음성을 재생하지 못했습니다.', recordingFailed: '음성을 녹음하지 못했습니다.', sayStopToEnd: phrase => `음성 대화를 끝내려면 "${phrase}"이라고 말하세요.`,
      transcriptionFailed: '음성을 텍스트로 변환하지 못했습니다.', transcriptionUnavailable: '아직 음성 텍스트 변환을 사용할 수 없습니다.', tryRecordingAgain: '다시 녹음해 보세요.', unavailable: '음성을 사용할 수 없습니다.',
      liveEnded: '실시간 음성 세션 종료', liveEndedConnectionLost: '실시간 음성 세션의 연결이 끊어졌습니다.', liveEndedClosed: '서비스가 실시간 음성 세션을 종료했습니다.',
      liveError: '실시간 음성', liveDelegationFailed: '요청을 Hermes에 전달하지 못했습니다.', liveUnavailable: reason => `GPT-Live 음성 대화를 사용할 수 없습니다: ${reason}. 대신 음성 텍스트 변환을 사용합니다.`
    },
    native: {
      approvalTitle: '승인 필요', approvalTitleNamed: session => `승인 필요 — ${session}`, approveAction: '승인', rejectAction: '거부', inputTitle: '입력 필요',
      inputTitleNamed: session => `입력 필요 — ${session}`, inputBody: 'Hermes가 응답을 기다리고 있습니다.', turnDoneTitle: 'Hermes 완료', turnDoneBody: '메시지 완료', turnErrorTitle: '요청 실패',
      backgroundDoneTitle: '백그라운드 작업 완료', backgroundFailedTitle: '백그라운드 작업 실패', creditsTitle: '크레딧'
    }
  },
  sendDiagnostics: { links: { github: 'GitHub 이슈', discord: 'Discord' } },
  skillDeepLink: {
    installTitle: name => `“${name}”을(를) 설치할까요?`, installDescription: '이 스킬은 새 세션에서 사용할 수 있습니다. 신뢰하는 출처의 스킬만 설치하세요.',
    installTo: '설치 위치', thisComputer: '이 컴퓨터', installing: '설치 중…', installComplete: name => `“${name}” 설치 완료`,
    destinationChanged: '설치 위치가 변경되었습니다. 대화상자를 닫고 설치 링크를 다시 여세요.', installed: '설치됨', source: '출처'
  },
  skills: { plugins: {
    kindDesktop: '데스크톱', kindBoth: '에이전트 + 데스크톱', toolsetOn: (name, profile) => `${profile} 프로필에서 ${name} 에이전트 도구 사용`,
    toolsetOff: (name, profile) => `${profile} 프로필에서 ${name} 에이전트 도구 사용 중지`, toolsetToggleFailed: name => `${name} 에이전트 도구를 전환하지 못해 Desktop 패널은 그대로 두었습니다.`,
    serverStates: { hermes_not_connected: 'MCP 연결 없음', unsupported_gpu: '지원하지 않는 GPU' }, settingsForm: { required: '필수' }
  } },
  webhooks: { deliverOptions: { telegram: 'Telegram', discord: 'Discord', slack: 'Slack' } },
  profiles: {
    fleet: { onGateway: (name, gateway) => `${name} · ${gateway}` },
    status: { working: count => `실행 중인 세션 ${count}개` },
    remoteOverride: { urlPlaceholder: 'https://hermes.example.com' }, openInNewWindow: '새 창에서 열기', setAsDefault: '기본값으로 설정', defaultProfile: '기본 프로필',
    defaultSet: name => `${name}을(를) 기본 프로필로 설정했습니다.`, defaultDescription: 'Hermes를 열 때와 새 대화를 시작할 때 사용합니다. 기존 세션은 각 프로필에 그대로 남습니다.',
    failedSetDefault: '기본 프로필을 설정하지 못했습니다.', exportMenu: '내보내기…', skillsLabel: '스킬',
    soulMissing: '이 프로필에는 아직 SOUL.md 파일이 없습니다. 아래에 지침을 추가하고 저장하면 파일이 만들어집니다. config.yaml의 성격 프리셋은 별도로 관리됩니다.'
  },
  statusStack: {
    previousTodos: (done, total) => `이전 작업 ${done}/${total}`,
    coding: { readOnlyScope: '읽기 전용 보기 — 스테이지, 되돌리기, 커밋은 미커밋 변경 사항에 적용됩니다.' }
  },
  updates: {
    copyFullLog: '전체 변경 기록 복사', pidLabel: pid => `프로세스 ID ${pid}`,
    applyStatus: { owed: steps => `백엔드는 업데이트했지만 아직 완료하지 않은 단계가 있습니다: ${steps}. 마치려면 \`hermes update\`를 다시 실행하세요.` },
    appName: 'Hermes', justNowSuffix: ' · 방금', bundleOutOfSync: '앱 빌드가 오래되었습니다.',
    bundleOutOfSyncDesc: 'Hermes 런타임은 업데이트되었지만 Desktop 앱은 이전 빌드입니다. 최신 수정 사항을 적용하려면 앱을 업데이트하세요.', bundleOutOfSyncAction: '설치 프로그램 받기',
    checkingShort: '확인 중…', releaseAvailable: tag => `버전 ${tag}을(를) 사용할 수 있습니다.`, versionDetailsTitle: '버전 세부 정보',
    versionDetailsBody: '앱 외부에서 관리되는 설치입니다. 처음 설치한 방식으로 업데이트하세요.', versionDetailsVersion: '버전', versionDetailsCommit: '커밋',
    versionDetailsBuildOrigin: '빌드 출처', versionDetailsDistribution: '배포 방식', versionDetailsDistributionDesktop: 'Desktop 앱',
    versionDetailsDistributionDesktopMsix: 'Desktop 앱 (MSIX)', versionDetailsDistributionDesktopInstaller: 'Desktop 앱 (설치 프로그램)',
    versionDetailsDistributionSourceInstaller: '소스 (설치 스크립트)', versionDetailsDistributionSourceInstallerDesktop: '소스 (설치 스크립트) + hermes desktop',
    versionDetailsDistributionSource: '소스', versionDetailsDistributionSourceDesktop: '소스 + hermes desktop', versionDetailsDistributionStore: 'Microsoft Store'
  },
  onboarding: { setupSlowTitle: '설정이 평소보다 오래 걸립니다.', setupSlowBody: 'Hermes가 백그라운드에서 계속 시작 중입니다.', continueWithoutSetup: '설정 없이 계속', pro: 'Pro' },
  rightSidebar: {
    terminalReadOnly: '읽기 전용 출력', terminalReadOnlyHelp: '프롬프트에 답하려면 백그라운드 명령을 중지하고 새 터미널에서 실행하세요. 새 터미널은 별도의 셸을 열며 이 프로세스에 연결되지 않습니다.',
    terminalOpenInteractive: '새 터미널 열기', folderTip: cwd => cwd, unreadableTitle: '읽을 수 없음', unreadableBody: error => `이 폴더를 읽지 못했습니다 (${error}).`,
    emptyTitle: '비어 있음', emptyBody: '이 폴더는 비어 있습니다.', treeErrorTitle: '파일 트리 오류', treeErrorBody: '이 폴더를 표시하는 중 파일 트리 오류가 발생했습니다.'
  },
  zones: { zoneMenuLabel: title => `${title} 영역 옵션` },
  prompts: { vaultSaveIdentifierPlaceholder: 'you@example.com' },
  ui: { logs: { bottom: '로그 끝', search: '로그 검색…', top: '로그 처음' } },
  shell: {
    modelMenu: {
      favorites: '즐겨찾기', addFavorite: '즐겨찾기에 추가', removeFavorite: '즐겨찾기에서 제거', favoriteShortcut: '⇧ 클릭', free: '무료', cacheRead: '캐시 읽기',
      priceTitle: (input, output, cache) => `입력 ${input}/Mtok · 출력 ${output}/Mtok` + (cache ? ` · 캐시 읽기 ${cache}/Mtok` : ''),
      localSetup: { title: '로컬에서 실행 · 무료, 비공개', text: (model, size) => `${model} 모델은 이 컴퓨터에서 실행할 수 있습니다 · 다운로드 ${size}`, action: '설정' },
      limited: '사용량 제한', limitedUntil: time => `${time}까지 제한`,
      limitedTip: (provider, time) => time ? `${provider}의 사용량 한도에 도달했습니다. ${time}에 초기화됩니다. 이후 사용할 모델은 지금 선택할 수 있습니다.` : `${provider}의 사용량 한도에 도달했습니다. 나중에 다시 시도하세요.`,
      modelResets: time => `${time}에 초기화`, modelLimitedTip: time => `이 모델의 한도에 도달해 ${time}에 초기화됩니다. 여기 있는 다른 모델은 계속 사용할 수 있습니다.`,
      usageLeft: (percent, time) => time ? `${percent}% 남음 · ${time}에 초기화` : `${percent}% 남음`,
      poolAccounts: count => `계정 ${count}개`, poolLimited: (limited, total) => `계정 ${total}개 중 ${limited}개 제한`, poolAccount: number => `계정 ${number}`,
      poolUnknown: '사용량을 확인할 수 없음', poolUnavailable: '다시 로그인하세요.', usageTip: provider => `${provider}의 사용량 한도에 가까워졌습니다.`,
      usageWindow: (label, percent, time) => time ? `${label}: ${percent}% 남음, ${time}에 초기화` : `${label}: ${percent}% 남음`
    },
    modelOptions: { ultrafast: '초고속', useStandardSpeed: '표준 속도 사용' },
    statusbar: {
      updateInProgress: '업데이트 진행 중', commitsBehind: (count, branch) => `${branch}보다 커밋 ${count}개 뒤처짐`,
      releaseAvailable: tag => `버전 ${tag}을(를) 사용할 수 있습니다.`, desktopVersion: version => `Hermes Desktop v${version}`, backendVersion: version => `백엔드 v${version}`,
      clientLabel: version => `클라이언트 v${version}`, connectionSsh: host => `SSH: ${host}`, connectionRemote: host => `원격: ${host}`, connectionCloud: host => `클라우드: ${host}`,
      connectionCloudTooltip: host => `Hermes Cloud · ${host}`, connectionSshTooltip: host => `SSH · ${host}`, connectionRemoteTooltip: host => `원격 · ${host}`,
      backendLabel: version => `백엔드 v${version}`, commit: sha => `커밋 ${sha}`, branch: branch => `브랜치 ${branch}`,
      closeCommandCenter: '명령 센터 닫기', openCommandCenter: '명령 센터 열기', showTerminal: '터미널 표시', hideTerminal: '터미널 숨기기', gateway: '게이트웨이', backend: '백엔드',
      messagingStopped: '메시징 중지됨', messagingDegraded: name => `${name} 중단`, gatewayReady: '준비됨', gatewayNeedsSetup: '설정 필요', gatewayUnavailable: '추론 사용 불가',
      gatewayChecking: '확인 중', gatewayConnecting: '연결 중', gatewayOffline: '오프라인', gatewayRestarting: '다시 시작 중…', gatewayTitle: '게이트웨이',
      customizeTitle: '상태 표시줄에 표시', hideStatusbar: '상태 표시줄 숨기기', resetStatusbar: '기본값으로 복원', toggleApprovalMode: '승인', toggleBackendVersion: '백엔드 버전',
      toggleCacheHitRate: '캐시 적중률', toggleCommandCenter: '명령 센터', toggleContextUsage: '컨텍스트 사용량', toggleRunningTimer: '요청 타이머', toggleSessionTimer: '세션 타이머',
      toggleTerminal: '터미널', toggleTokensPerSecond: '초당 토큰', toggleVersion: '버전 및 업데이트', toggleFreeTier: '무료 티어', toggleWorkspace: '작업 공간',
      cacheHitRateTitle: '이 세션의 프롬프트 캐시 적중률입니다. 캐시 토큰은 비용이 더 저렴하므로 적중률이 높을수록 유리합니다.',
      tokensPerSecondTitle: '최근 모델 호출 10회의 평균 초당 출력 토큰 수', agents: '에이전트', closeAgents: '에이전트 닫기', openAgents: '에이전트 열기',
      subagents: count => `하위 에이전트 ${count}개`, failed: count => `${count}개 실패`, running: count => `${count}개 실행 중`, cron: '예약 작업', openCron: '예약 작업 열기', webhooks: '웹훅', openWebhooks: '웹훅 열기',
      starmap: '메모리 그래프', openStarmap: '메모리 그래프 열기', turnRunning: '실행 중', contextUsage: '컨텍스트 사용량', compressions: count => `압축: ${count}회`,
      systemResources: { title: '시스템 리소스', loading: '리소스 확인 중…', gpuUtilization: 'GPU 사용률', gpuMemory: 'GPU 메모리', ram: 'RAM', unifiedNote: '통합 메모리 — GPU와 시스템이 메모리를 함께 사용합니다.', toggle: '시스템 리소스' },
      contextUsagePanel: {
        categories: { conversation: '대화', mcp: 'MCP', memory: '메모리', rules: '규칙', skills: '스킬', subagent_definitions: '하위 에이전트 정의', system_prompt: '시스템 프롬프트', tool_definitions: '도구 정의' },
        empty: '아직 컨텍스트 데이터가 없습니다.', loading: '세부 정보 불러오는 중…', percentFull: percent => `${percent}% 사용`, title: '컨텍스트 사용량', tokenSummary: (used, max) => `${used} / ${max} 토큰`
      },
      focusedSince: '집중한 시간', focusedSinceTitle: '이 채팅에 집중한 시간입니다. 요청 실행 시간과는 다릅니다.',
      yoloOn: 'YOLO 켜짐 — 위험한 명령을 자동 승인합니다. Shift+클릭으로 전역 설정을 바꿉니다.', yoloOff: 'YOLO 꺼짐. Shift+클릭으로 전역 설정을 바꿉니다.',
      modelNone: '없음', noModel: '모델 없음', switchModel: '모델 전환', openModelPicker: '모델 선택기 열기', modelPinned: '직접 고정됨. 새 채팅은 설정의 기본값 대신 이 모델을 사용합니다.',
      modelTitle: (provider, model) => `모델 · ${provider}: ${model}`, providerModelTitle: (provider, model) => `${provider} · ${model}`
    }
  },
  sidebar: {
    filter: {
      pullRequest: '풀 리퀘스트', profile: '프로필', project: '프로젝트', archived: '보관됨', resetToDefaults: '기본값으로 복원', expandAll: '모두 펼치기', collapseAll: '모두 접기',
      inboxStyle: '받은 편지함 스타일', updated: '수정일', created: '생성일', tokens: '토큰', cost: '비용', manual: '직접 지정', preview: '미리 보기', pr: 'PR', needsInput: '입력 필요', working: '작업 중', unread: '읽지 않음', draft: '초안', idle: '대기 중', open: '열림', merged: '병합됨', closed: '닫힘', noPR: 'PR 없음'
    },
    gatewayGroups: { grouping: '게이트웨이 및 프로필', rename: '그룹 이름 바꾸기', aliasLabel: '표시 이름', aliasHint: '표시 이름만 바뀝니다. 게이트웨이와 프로필 이름은 그대로입니다.', resetName: '이름 초기화', moveUp: '위로 이동', moveDown: '아래로 이동', reorder: '그룹 순서 변경', actions: '그룹 작업' },
    profileRail: '프로필 목록', nav: { capabilities: '기능' }, terminal: '터미널', files: '파일', review: '검토', logs: '로그',
    groupAriaGrouped: '세션을 하나의 목록으로 표시', groupAriaUngrouped: '작업 공간별로 세션 그룹화', groupTitleGrouped: '그룹 해제', groupTitleUngrouped: '작업 공간별로 그룹화',
    allPinned: '모든 항목이 고정되어 있습니다. 최근 항목에 표시하려면 채팅 고정을 해제하세요.', shiftClickHint: '채팅을 Shift+클릭하여 고정', projectLoadFailed: '세션을 불러오지 못했습니다.',
    storageCorrupt: {
      title: '세션 데이터베이스 손상', body: profiles => `Hermes가 ${profiles}의 세션 기록을 모두 읽지 못합니다. 목록에 없는 채팅은 삭제되지 않았습니다. 자세한 내용은 복구 안내를 참조하세요.`,
      action: '이 프로필의 Hermes를 종료한 다음 파일을 변경하지 않고 살펴보거나 스냅샷을 복원하세요:', guide: '복구 안내'
    },
    projects: {
      showAllSessions: '모든 세션 표시', sectionLabel: '프로젝트', home: '홈', autoDiscovered: '자동 검색됨', newButton: '새 프로젝트', createTitle: '새 프로젝트',
      createDesc: '작업 공간 이름을 지정하고 폴더를 하나 이상 추가하세요.', renameTitle: '프로젝트 이름 바꾸기', addFolderTitle: '폴더 추가', namePlaceholder: '예: 실험 프로젝트', foldersLabel: '폴더',
      ideaLabel: '아이디어', ideaPlaceholder: '이 프로젝트는 어떤 내용인가요? (IDEA.md에 저장)', ideaGenerate: '아이디어 만들기', ideaGenerating: '만드는 중…', ideaShuffle: '템플릿 섞기', noFolders: '아직 추가된 폴더가 없습니다.', addFolder: '폴더 추가', primaryBadge: '기본', removeFolder: '제거', create: '만들기', menu: '작업', menuRename: '이름 바꾸기…', menuAppearance: '모양', noColor: '색상 없음', menuAddFolder: '폴더 추가', menuSetActive: '활성으로 설정', menuDelete: '삭제',
      moveToProject: '프로젝트로 이동', movedTo: name => `${name}(으)로 이동했습니다.`, moveFailed: '세션을 이동하지 못했습니다.', moveNoFolder: '이 프로젝트에는 이동할 폴더가 없습니다.', moveNoProjects: '다른 프로젝트가 없습니다.', reveal: '폴더에서 보기', copyPath: '경로 복사', removeFromSidebar: '사이드바에서 숨기기',
      createdInPreviousContext: '이전 연결 또는 프로필에서 만든 프로젝트입니다. 프로젝트를 찾으려면 해당 항목으로 전환하세요. IDEA.md는 작성되지 않았습니다.', hiddenFromSidebar: '사이드바에서 숨김', undoHide: '실행 취소', createFailed: '프로젝트를 만들지 못했습니다.',
      staleBackend: '프로젝트를 만들려면 Hermes 백엔드를 업데이트하세요. 백엔드가 이 Desktop 앱보다 오래되었습니다 (설정 → 업데이트 → 백엔드).', deleteConfirm: 'Hermes에서 저장된 프로젝트만 제거합니다. 파일, Git 저장소, 작업 트리는 그대로 유지됩니다.',
      startWork: '새 작업 트리', newWorktreeTitle: '새 작업 트리', newWorktreeDesc: '작업 트리에 사용할 브랜치 이름을 입력하세요.', branchPlaceholder: '예: my-feature', branchOff: () => ({ after: '', before: '다음에서 분기: ' }),
      baseBranchPlaceholder: '브랜치 검색…', baseBranchNone: '브랜치를 찾지 못했습니다.', startWorkFailed: '작업 트리를 만들지 못했습니다.', worktreeStaleBackend: '이 원격 연결에서 작업 트리를 만들려면 Hermes 백엔드를 업데이트하세요. 백엔드가 Git 작업 트리 API보다 오래되었습니다.',
      worktreeProjectLabel: '프로젝트', worktreeProjectPlaceholder: '프로젝트 검색…', worktreeProjectNone: '폴더가 있는 프로젝트가 없습니다.', convertBranch: '브랜치 변환…', convertBranchTitle: '브랜치 변환', convertBranchDesc: '체크아웃된 브랜치를 열거나 사용 가능한 브랜치에서 작업 트리를 만드세요.', convertBranchPlaceholder: '브랜치 검색…', convertBranchInstead: '기존 브랜치 변환',
      branchOpenExisting: '열기', branchSwitchHome: '홈으로 전환', branchCreateWorktree: '새 작업 트리', branchTrackRemote: '원격 추적', branchesLoading: '브랜치 불러오는 중…', noBranches: '브랜치가 없습니다.', removeWorktree: '작업 트리 제거', removeWorktreeFailed: '작업 트리를 제거하지 못했습니다 (커밋하지 않은 변경 사항이 있나요?)',
      removeWorktreeConfirm: 'Git에서 제거하여 작업 트리 폴더를 삭제할 수 있습니다 (브랜치는 유지). 또는 사이드바에서만 숨기고 작업 트리를 남길 수 있습니다.', removeWorktreeDirty: '이 작업 트리에 커밋하지 않은 변경 사항이 있습니다. 강제로 제거해 변경 사항을 버리거나 사이드바에서만 숨기고 디스크에 보관하세요.', forceRemove: '강제 제거',
      enter: label => `${label} 열기`, reorder: label => `${label} 순서 변경`, toggle: (label, open) => `${label} 세션 ${open ? '표시' : '숨기기'}`, showAllCount: count => `세션 ${count}개 모두 표시`, back: '모든 프로젝트'
    },
    newSessionIn: label => `${label}에서 새 세션`, showMoreIn: (count, label) => `${label}에서 ${count}개 더 보기`, loadCount: step => `${step}개 더 불러오기`,
    row: {
      unreadFailed: '읽지 않음 상태를 변경하지 못했습니다.', unarchive: '보관 취소', hideTabBar: '탭 표시줄 숨기기', openInNewTab: '새 탭에서 열기', openInSplit: '분할 화면에서 열기', copyIdFailed: '세션 ID를 복사하지 못했습니다.', draftSession: '초안 — 아직 전송한 내용이 없습니다.',
      handoffOrigin: platform => `${platform}에서 이어받음`, continuationOrigin: '대화 내용을 압축한 뒤 자동으로 이어간 대화입니다.', ownedByProfile: profile => `프로필: ${profile}`, renamed: '이름 변경됨', renameFailed: '이름을 바꾸지 못했습니다.', renameDesc: '비워 두면 이름이 지워집니다.', untitledPlaceholder: '제목 없는 세션', deleteDesc: title => `“${title}” 세션을 영구 삭제합니다. 되돌릴 수 없습니다.`, untitledChat: id => `채팅 ${id}`, messageCount: count => `메시지 ${count}개`, todoProgress: '완료한 작업', ageNow: '방금', ageDay: '일', ageHour: '시간', ageMin: '분'
    }
  },
  preview: {
    pin: '작업 공간에 고정', unpin: '작업 공간에서 고정 해제', missingTarget: '이 컴퓨터에 해당 경로가 없습니다.', missingTitle: '파일이 더 이상 없습니다.',
    missingBody: label => `${label} 파일이 삭제되거나 이동되었거나 임시 위치가 정리되었습니다. 다음 실행 때 이 탭은 복원되지 않습니다.`, largeBody: (label, size) => `${label} 크기가 ${size}입니다. Hermes는 처음 512KB만 표시합니다.`,
    noInlineTitle: '인라인 미리 보기 없음', noInlineBody: mimeType => `${mimeType || '이 파일 형식'}은(는) 컨텍스트로 첨부할 수 있습니다.`, saveFailed: message => `저장하지 못했습니다: ${message}`, saveScopeChanged: '초안을 저장하려면 원래 연결 및 프로필로 다시 전환하세요.',
    diskChangedTitle: '디스크의 파일이 변경됨', diskChangedBody: '파일을 연 뒤 내용이 바뀌었습니다. 현재 내용으로 덮어쓰거나 편집을 버리고 다시 불러오세요.',
    console: {
      deselect: '항목 선택 해제', select: '항목 선택', copyFailed: '콘솔 출력을 복사하지 못했습니다.', copyEntry: '이 항목 복사', sendEntry: '이 항목을 채팅에 보내기', messages: count => `콘솔 메시지 ${count}개`, resize: '미리 보기 콘솔 크기 조절', title: '미리 보기 콘솔', selected: count => `${count}개 선택됨`, sendToChat: '채팅에 보내기', copySelected: '선택 항목을 클립보드에 복사', copyAll: '모두 클립보드에 복사', copy: '복사', clear: '지우기', empty: '아직 콘솔 메시지가 없습니다.', promptHeader: '미리 보기 콘솔:', sentTitle: '채팅에 보냄', sentMessage: count => `로그 ${count}개를 입력창에 추가했습니다.`
    },
    web: {
      appFailedToBoot: '미리 보기 앱을 시작하지 못했습니다.', serverNotFound: '서버를 찾지 못했습니다.', remoteLoopback: '이 주소는 현재 컴퓨터가 아니라 에이전트가 실행 중인 컴퓨터를 가리킵니다. 브라우저 창은 로컬 페이지를 불러오므로 원격 개발 서버 주소를 사용할 수 없습니다.', failedToLoad: '미리 보기를 불러오지 못했습니다.', tryAgain: '다시 시도', restarting: 'Hermes 다시 시작 중…', askRestart: 'Hermes에 서버 다시 시작 요청',
      lookingRestart: taskId => `Hermes가 다시 시작할 미리 보기 서버를 찾는 중 (${taskId})`, restartingTitle: '미리 보기 서버 다시 시작 중', restartingMessage: 'Hermes가 백그라운드에서 작업 중입니다. 진행 상황은 미리 보기 콘솔에서 확인하세요.', startRestartFailed: message => `서버 다시 시작을 시작하지 못했습니다: ${message}`, restartFailed: '서버를 다시 시작하지 못했습니다.', hideConsole: '미리 보기 콘솔 숨기기', showConsole: '미리 보기 콘솔 표시', hideDevTools: '미리 보기 개발자 도구 숨기기', openDevTools: '미리 보기 개발자 도구 열기',
      goBack: '뒤로', goForward: '앞으로', reload: '페이지 새로고침', address: '주소', addressPlaceholder: '주소 입력', blankPageBody: '위에 주소를 입력해 둘러보거나 Hermes에 페이지를 열어 달라고 요청하세요.',
      finishedRestarting: message => `Hermes가 미리 보기 서버를 다시 시작했습니다${message ? `: ${message}` : ''}`, failedRestarting: message => `서버를 다시 시작하지 못했습니다: ${message}`, unknownError: '알 수 없는 오류', restartedTitle: '미리 보기 서버 다시 시작 완료', reloadingNow: '미리 보기를 다시 불러옵니다.', restartFailedTitle: '미리 보기 다시 시작 실패', restartFailedMessage: 'Hermes가 서버를 다시 시작하지 못했습니다.', stillWorking: 'Hermes가 계속 작업 중이지만 다시 시작 결과가 아직 도착하지 않았습니다. 서버 명령이 포그라운드에서 실행 중일 수 있습니다.', workspaceReloading: '작업 공간이 변경되어 미리 보기를 다시 불러옵니다.',
      fileChanged: url => `파일이 변경되어 미리 보기를 다시 불러옵니다: ${url}`, filesChanged: (count, url) => `파일 ${count}개가 변경되어 미리 보기를 다시 불러옵니다: ${url}`, watchFailed: message => `미리 보기 파일을 감시하지 못했습니다: ${message}`,
      moduleMimeDescription: '모듈 스크립트가 잘못된 MIME 유형으로 제공되고 있습니다. 정적 파일 서버가 Vite/React 앱을 제공하는 경우에 주로 발생합니다. Vite 개발 서버를 사용하세요.', loadFailedConsole: (code, message) => `불러오기 실패${code ? ` (${code})` : ''}: ${message}`, unreachableDescription: '미리 보기 페이지에 연결할 수 없습니다.', openTarget: url => `${url} 열기`, fallbackTitle: '미리 보기',
      annotate: '주석 달기', annotateOn: '주석 모드 종료', annotateNeedPage: '먼저 앱 내 브라우저에서 페이지를 여세요.', annotateFailed: '주석 모드를 시작하지 못했습니다.', commenting: '댓글 작성 중', addComments: count => `댓글 ${count}개 추가`, commentPlaceholder: '댓글 추가…', commentTitle: n => `댓글 ${n}`, saveComment: '저장', cancelComment: '댓글 취소'
    }
  },
  settings: {
    pluginPages: {
      blurb: '설치된 플러그인이 추가하는 옵션입니다. 플러그인마다 자체 페이지가 있으며 하위 페이지를 추가하는 플러그인도 있습니다.',
      empty: '아직 설정이 있는 플러그인이 없습니다.', manage: '플러그인 관리', agentSettings: '에이전트 설정',
      pageCount: n => `페이지 ${n}개`, missing: '이 플러그인에는 설정 페이지가 없습니다. 사용 중지되었거나 제거되었을 수 있습니다.'
    },
    nav: { mcp: 'MCP', plugins: '플러그인' }, sessions: { messages: count => `${count}개 메시지` },
    plugins: { installModal: {
      repoPlaceholder: 'https://github.com/owner/repo', pinToCommit: '커밋에 고정 (선택 사항)', pinToCommitPlaceholder: '40자리 전체 커밋 SHA',
      pinToCommitHint: '이 SHA로 설치하면 누구나 같은 코드를 받습니다. 고정을 다시 설정하기 전까지 플러그인이 업데이트를 거부합니다. 최신 커밋을 사용하려면 비워 두세요.',
      pinToCommitInvalid: '40자리 전체 커밋 SHA여야 합니다. 브랜치와 태그는 사용할 수 없습니다.',
      installUncertain: 'Hermes가 설치 결과를 기다리지 않고 종료했지만 플러그인 설치는 계속 진행 중일 수 있습니다. 대화상자를 닫고 플러그인에서 다시 검색한 뒤 설치를 다시 시도하세요.',
      missingEnv: (name, vars) => `${name}을(를) 설치했지만 작동하려면 키가 필요합니다: ${vars}. 지금 추가하세요. 그렇지 않으면 플러그인 도구가 실패합니다.`
    } },
    vault: {
      adding: '저장 중…', addConfirm: '저장', kindField: '종류', kinds: { login: '로그인', payment: '결제 카드', address: '주소' },
      labelField: '이름표', labelPlaceholder: '예: GitHub 업무 계정', labelRequired: '이름표를 입력하세요.', originField: '사이트 출처',
      originPlaceholder: 'https://github.com', originPlaceholderCheckout: 'https://shop.example.com', originInvalid: 'https://example.com 형식의 올바른 URL을 입력하세요.',
      identifierTypeField: '식별자 유형', identifierTypes: { email: '이메일', phone: '전화번호', username: '사용자 이름' }, identifierField: '식별자',
      identifierShown: identifier => identifier, passwordField: '비밀번호', loginFieldsRequired: '식별자와 비밀번호를 입력하세요.',
      cardNumberField: '카드 번호', cardNameField: '카드 명의자', expMonthField: '만료 월', expYearField: '만료 연도', cvcField: 'CVC', postalField: '우편번호',
      addressLine1Field: '주소 1', addressLine2Field: '주소 2', cityField: '시/군/구', stateField: '도/지역', countryField: '국가', optional: '(선택 사항)',
      createdOn: date => `${date}에 추가`, deleteAction: '저장된 항목 삭제', otpField: '인증 키', otpPlaceholder: 'Base32 비밀 키 또는 otpauth:// 링크',
      otpHint: '사이트에서 2단계 인증을 켤 때 표시되는 설정 키입니다. 저장하면 Hermes가 인증 코드를 직접 생성합니다.', twoFactorBadge: '2FA 자동',
      deleteTitle: '이 항목을 삭제할까요?', deleteDescription: label => `“${label}” 항목이 삭제되며 복구할 수 없습니다.`, deleteConfirm: '삭제',
      sources: {
        title: '비밀번호 관리자', blurb: '설치된 비밀번호 관리자를 자동으로 찾습니다. 세션마다 처음 로그인이 필요할 때 에이전트가 잠금 해제를 요청합니다. 세션 토큰만 보관하고 비밀번호는 저장하지 않습니다.',
        toggleFailed: '비밀번호 관리자를 변경하지 못했습니다.', notInstalled: name => `감지되지 않았습니다. ${name} 명령줄 도구를 설치하고 로그인하면 Hermes가 자동으로 찾습니다.`,
        disabledDesc: '감지했지만 Hermes에서 꺼져 있습니다.', lockedDesc: '감지했습니다. 로그인이 필요할 때 잠금 해제를 요청하거나 지금 잠금을 해제합니다.',
        unlockedDesc: '이 세션에서 잠금 해제되었습니다. 30분 동안 사용하지 않거나 Hermes를 종료하면 자동으로 잠깁니다.',
        statusLocked: '잠김', statusNotDetected: '감지되지 않음', statusOff: '꺼짐', statusUnlocked: '잠금 해제됨', unlock: '잠금 해제', unlocking: '잠금 해제 중…', lock: '잠그기',
        unlocked: name => `이 세션에서 ${name} 잠금을 해제했습니다.`, unlockTitle: name => `${name} 잠금 해제`,
        unlockDescription: '마스터 비밀번호를 입력하세요. 이 컴퓨터의 비밀번호 관리자에 전달한 뒤 폐기하며 저장하거나 기록하지 않고 에이전트에도 표시하지 않습니다.', masterPasswordPlaceholder: '마스터 비밀번호'
      }
    },
    notifications: { testTitle: 'Hermes' },
    appearance: {
      chatTextScaleTitle: '채팅 글자 크기', chatTextScaleDesc: 'UI 배율에 맞춰 대화와 메시지 입력창의 글자 크기를 조정합니다. 사이드바와 컨트롤 크기는 유지됩니다.',
      chatFontTitle: '채팅 글꼴', chatFontDesc: '채팅과 앱 전체에 설치된 글꼴을 사용합니다. OpenDyslexic처럼 읽기 쉬운 글꼴을 선택하거나 비워 두면 테마 글꼴을 사용합니다.',
      chatFontPlaceholder: 'OpenDyslexic 또는 CSS 글꼴 목록', chatFontPreview: '미리 보기', chatFontSample: '다람쥐 헌 쳇바퀴에 타고파. 0123456789', chatFontReset: '테마 글꼴 사용',
      userBubbleTitle: '메시지 말풍선', userBubbleDesc: '내 메시지의 투명도를 설정합니다. 0에서는 불투명하고 100에서는 윤곽선만 남습니다.', textDirectionTitle: '텍스트 방향',
      textDirectionDesc: '채팅 메시지와 입력창의 텍스트 방향을 정합니다. 자동은 문단의 첫 글자를 따릅니다. 혼합 텍스트의 정렬이 어긋나면 방향을 직접 선택하세요. 코드는 항상 왼쪽에서 오른쪽으로 표시됩니다.',
      textDirection: { auto: '자동', rtl: '오른쪽에서 왼쪽', ltr: '왼쪽에서 오른쪽' },
      modelPricingTitle: '모델 가격', modelPricingDesc: '모델 선택기에 입력, 출력, 캐시 읽기의 토큰 백만 개당 가격을 표시합니다.',
      tipsTitle: '앱 도움말', tipsDesc: '앱과 Hermes의 유용한 팁을 표시합니다. 각 팁은 한 번만 나타납니다. 처음 30일이 지나면 자동으로 꺼지며 다시 켤 수 있습니다.',
      tipsReset: count => `팁 ${count}개 다시 표시`, toursTitle: '가이드 투어', toursDesc: '앱 사용법을 안내하도록 각 단계를 강조 표시합니다. 처음 30일이 지나면 자동으로 꺼지며 다시 켤 수 있습니다.',
      fileBrowserTitle: '파일 브라우저', fileBrowserDesc: '작업 공간을 열었을 때 채팅 옆에 파일 브라우저를 표시합니다. 제목 표시줄의 토글로도 설정할 수 있습니다.',
      embedsReset: count => `허용된 서비스 ${count}개 초기화`, resumeLastSessionTitle: '시작할 때 마지막 채팅 다시 열기',
      resumeLastSessionDesc: '켜면 앱을 완전히 종료한 뒤 다시 시작할 때 가장 최근 채팅을 엽니다. 끄면 항상 새 대화로 시작합니다.',
      themeSearchPlaceholder: '테마 또는 VS Code Marketplace 검색…', installPlaceholder: 'publisher.extension', pet: { count: n => `반려동물 ${n}마리` }
    },
    model: {
      setupProviderFallback: '공급자', setUpProvider: name => `${name} 설정`, staleAuxBefore: (count, names) => `보조 작업 ${count}개 (${names})가 아직 `, staleAuxAfter: ', 기본 모델이 아닌 다른 모델에서 실행 중입니다.', staleAuxOtherProviders: '다른 공급자',
      moaEnabled: '사용', moaSetDefault: '기본값으로 설정', moaNewPresetPlaceholder: '새 프리셋', moaAddPreset: '프리셋 추가', customModel: '사용자 지정 모델…', customModelPlaceholder: '모델 ID', chooseFromList: '목록에서 선택', moaDefault: '기본값:',
      moaReferenceToggle: (enabled, index) => `참조 ${index} ${enabled ? '사용 중지' : '사용'}`, moaReferenceTitle: index => `참조 ${index}`, moaAddReference: '참조 모델 추가', mainAppliedTitle: '기본 모델 업데이트됨', mainAppliedMessage: model => `새 세션에서 ${model} 모델을 사용합니다.`,
      speed: '속도', speedStandard: '표준', loadFailed: '모델을 불러오지 못했습니다.', restartRequired: '업데이트 후 이 백엔드에서 이전 코드가 실행 중입니다. 새 코드를 불러오려면 다시 시작하세요.', restartBackend: '백엔드 다시 시작', restartingBackend: '백엔드 다시 시작 중…', restartFailed: '백엔드를 다시 시작하지 못했습니다.', staleAuxDismiss: '다시 표시하지 않기',
      autoUseMain: '자동 · 기본 모델 사용', inheritMainEffort: '상속 · 기본 모델의 추론 수준', inheritsFrom: task => `${task}에서 상속`, followTask: task => `${task} 따르기`, moaTitle: '에이전트 혼합 (MoA)', moaPreset: '프리셋',
      moaDescription: '에이전트 혼합 공급자 아래 모델로 표시할 이름 있는 프리셋을 설정합니다. 집계 모델은 전체 단계를 실행하는 주 모델입니다. 참조 모델은 기본적으로 요청마다 한 번씩 조언합니다.', moaAggregator: '집계 모델', moaAggregatorBilled: '실행 모델 · 실행 비용이 청구됩니다.', moaReferenceHint: '기본값으로 요청마다 한 번 조언합니다.',
      tasks: {
        skills_hub: { label: '스킬 허브' }, mcp: { label: 'MCP' }, review: { hint: '/review 검토 하위 에이전트' }, voice_chat: { label: '음성 대화', hint: '음성 모드 답변을 소리 내어 읽기' },
        triage_specifier: { label: '분류 명세 작성자', hint: '칸반 명세 구체화' }, kanban_decomposer: { label: '칸반 작업 분해기', hint: '작업 분해' }, profile_describer: { label: '프로필 설명 생성기', hint: '프로필 설명 자동 생성' }, curator: { hint: '스킬 사용 검토' }
      }
    },
    toolsets: {
      nousAuthFailedMessage: '다시 시도하세요.', nousAuthTryAgain: '다시 시도', postSetupOpenLogs: '로그 열기', postSetupRunAgain: '다시 실행',
      webSearchActive: backend => `검색: ${backend}`, webExtractActive: backend => `추출: ${backend}`, failedSelectCapability: provider => `${provider} 설정에 실패했습니다.`, modelCount: count => `모델 ${count}개`, failedSelectModel: model => `${model} 모델을 선택하지 못했습니다.`,
      terminalBackend: {
        failedSelect: backend => `${backend} 선택에 실패했습니다.`, needsSetupConfirmTitle: backend => `${backend}을(를) 그래도 선택할까요?`, needsSetupConfirmDescription: detail => `${detail} 이 변경 후 시작하는 세션에는 설정이 끝날 때까지 터미널 또는 파일 도구가 없습니다.`,
        needsSetupConfirmDescriptionGeneric: '이 백엔드는 아직 설정되지 않았습니다. 설정을 마칠 때까지 이후 시작하는 세션에서 터미널 또는 파일 도구를 사용할 수 없습니다.', needsSetupConfirmAction: '그래도 선택', unavailableTitle: '터미널 명령을 사용할 수 없습니다.',
        unavailableMessage: backend => `Hermes에서 지금 셸 명령을 실행할 수 없습니다. ${backend}이(가) 준비되지 않았습니다. 로컬로 전환하거나 ${backend} 설정을 마친 뒤 다시 시도하세요.`, openBackendSettings: '터미널 설정 열기', useLocal: '로컬 사용', switchedToLocal: '터미널 명령을 로컬에서 실행합니다. 새 세션부터 적용됩니다.'
      },
      browserRealProfile: {
        label: '실제 브라우저 프로필 사용', description: '기본 브라우저의 로그인과 쿠키를 관리되는 스냅샷에 복사하여 에이전트가 사용합니다. 실제 프로필을 직접 열지 않습니다. 새 세션부터 적용됩니다.',
        enabledTitle: '실제 프로필 탐색 켜짐', enabledMessage: '새 세션은 기본 브라우저 프로필의 스냅샷으로 탐색합니다.', disabledTitle: '실제 프로필 탐색 꺼짐', disabledMessage: '프로필 스냅샷이 삭제되며 새 세션에서는 새 브라우저를 사용합니다.', failedSave: '실제 프로필 설정을 저장하지 못했습니다.',
        prompt: { title: '사이트 로그인 상태 유지', body: '기본 브라우저 프로필의 스냅샷을 사용하도록 허용하면 사이트가 로그인된 상태로 열립니다.', bulletSnapshot: '쿠키와 로그인을 관리되는 스냅샷에 복사합니다.', bulletLiveProfile: '실제 브라우저 프로필을 직접 열지 않습니다.', bulletLocal: '이 컴퓨터 밖으로 데이터가 나가지 않습니다.', dontShowAgain: '다시 표시하지 않기', notNow: '나중에', enable: '내 프로필 사용' }
      }
    },
    customEndpoints: {
      active: '사용 중', apiKeySet: 'API 키 설정됨', use: '사용', editTitle: '엔드포인트 수정', addTitle: '엔드포인트 추가',
      fields: { name: '이름', providerId: '공급자 ID', endpointUrl: '엔드포인트 URL', defaultModel: '기본 모델', context: '컨텍스트', apiKey: 'API 키', apiKeyNewPlaceholder: '현재 키를 유지하려면 비워 두세요', apiKeyPlaceholder: '선택 사항', useNewChats: '새 채팅에 사용', discoverModels: '모델 검색' },
      test: '테스트', newEndpoint: '새 엔드포인트', apiMode: 'API 모드', autoDetect: '자동 감지', couldNotLoad: '사용자 지정 엔드포인트를 불러오지 못했습니다.', endpointSaved: '사용자 지정 엔드포인트를 저장했습니다.', saveFailed: '저장하지 못했습니다.', endpointReachable: '엔드포인트에 연결할 수 있습니다.',
      endpointReachableTransport: transport => `엔드포인트에 연결할 수 있습니다 (${transport} 경로로 응답).`, endpointReachableModels: (reachable, count) => `${reachable} 모델 ${count}개를 찾았습니다.`, endpointValidationFailed: '엔드포인트 검증에 실패했습니다.', validationFailed: '검증 실패', activationFailed: '활성화 실패', deleteConfirm: name => `${name}을(를) 삭제할까요?`, deleteFailed: '삭제하지 못했습니다.', deleteEndpoint: '엔드포인트 삭제', emptyDescription: '아래에 OpenAI 호환 엔드포인트를 추가하세요.', emptyTitle: '사용자 지정 엔드포인트 없음', namePlaceholder: 'Axet Proxy', contextPlaceholder: '자동'
    },
    config: {
      minimizeToTrayTitle: '시스템 트레이로 최소화', minimizeToTrayDesc: '창을 최소화하거나 주 창을 닫으면 시스템 트레이(macOS는 메뉴 막대)에 숨기고 Hermes를 계속 실행합니다. 트레이 메뉴에서 Hermes 종료를 선택하세요.',
      minimizeToTrayUnavailable: '시스템 트레이를 사용할 수 없습니다. 창이 일반적으로 최소화되거나 닫힙니다. 다시 시도하려면 이 옵션을 껐다가 켜세요.', keepAwakeOff: '끔', keepAwakeWhileWorking: '작업 중', keepAwakeAlways: '항상',
      alwaysExternalLinksTitle: '항상 외부 브라우저에서 링크 열기', alwaysExternalLinksDesc: '클릭한 모든 링크를 앱 내 브라우저 대신 시스템 브라우저에서 엽니다. 오른쪽 클릭 메뉴의 “앱 내 브라우저에서 열기”는 계속 사용할 수 있습니다.',
      developerTitle: '개발자', resetOnboardingTitle: '초기 설정 재설정', resetOnboardingDesc: '설정 대화를 삭제하고 설정 프로필을 다시 만든 뒤 첫 실행 설정을 시작합니다. 개인 프로필, 채팅, 플러그인은 유지됩니다.', resetOnboardingAction: '재설정', resetOnboardingFailed: '초기 설정을 재설정하지 못했습니다.', attachmentSizeUnit: 'MB',
      voiceShortcutHintTitle: '음성 녹음 단축키', voiceShortcutHintDesc: '설정 → 키보드 단축키의 “음성 대화 시작/중지”에서 녹음 단축키를 지정하세요. voice.record_key 설정도 함께 변경됩니다.', showOptions: '옵션 표시'
    },
    localModels: {
      installDetail: 'llama.cpp 추론 엔진(수백 MB)을 다운로드합니다. 다운로드한 모델은 모두 이 컴퓨터에서 실행되며 계정이 필요 없고 데이터가 밖으로 나가지 않습니다.', installing: '런타임 설치 중…', installFailed: '런타임을 설치하지 못했습니다.',
      hardwareTitle: '이 컴퓨터', hardwareLoading: '하드웨어 확인 중…', vram: label => `${label} GPU 메모리`, ram: label => `${label} RAM`, unifiedMemory: '통합 메모리', modelsTitle: '모델', recommended: '추천',
      recommendedReason: {
        'product-default': '제조업체가 이 컴퓨터의 기본 모델로 선택했습니다.', 'best-quality-resident': 'GPU에서 최고 속도로 완전히 실행되는 모델 중 품질이 가장 높습니다. 이 하드웨어에서 예상 속도와 품질을 고려해 선택했습니다.',
        'speed-gated-quality': '더 높은 품질의 모델도 실행할 수 있지만 메모리 대역폭 때문에 응답이 너무 느립니다. 이 모델은 빠르게 작동하는 범위에서 품질이 가장 높습니다.',
        'fastest-resident': '이 하드웨어에서 최고 속도를 내는 모델은 없습니다. 이 모델은 GPU 메모리에서 실행되는 모델 중 가장 빠릅니다.'
      },
      noRecommendationTitle: '이 컴퓨터에 자동 추천할 모델이 없습니다.', noRecommendationDetail: '자동 설정은 GPU 또는 통합 메모리에 완전히 들어가는 검증된 모델만 사용합니다. 아래에서 직접 모델을 선택하거나 더 찾아볼 수 있습니다.', noRecommendationAction: '모델 찾아보기',
      downloaded: '다운로드됨', downloadAction: size => `다운로드 · ${size}`, downloadStatusRunning: '다운로드 중', downloadSpeed: rate => `${rate}`, downloadEta: time => `약 ${time} 남음`, downloadEtaSeconds: count => `${count}초`, downloadEtaMinutes: count => `${count}분`, downloadEtaHours: (hours, minutes) => minutes ? `${hours}시간 ${minutes}분` : `${hours}시간`,
      downloadPausedLabel: '일시 정지됨', downloadPauseAction: '일시 정지', downloadResumeAction: '계속', downloadDoneToast: model => `${model} 준비 완료`, installDoneToast: '로컬 런타임을 설치했습니다.',
      quickstartTitle: '이 컴퓨터에서 모델 실행', quickstartDetail: (model, size) => `한 번의 클릭으로 로컬 엔진과 ${model} 모델(${size} 다운로드)을 설정하고 새 채팅의 기본값으로 지정합니다. 데이터가 이 컴퓨터 밖으로 나가지 않습니다.`,
      quickstartDetailReady: model => `한 번의 클릭으로 ${model}을(를) 새 채팅의 기본 모델로 설정합니다. 이 컴퓨터에서 모두 실행됩니다.`, quickstartAction: '자동 설정', quickstartConfigure: '직접 선택', quickstartDoneToast: model => `${model} 설정 완료 — 새 채팅은 이 컴퓨터에서 실행됩니다.`, quickstartFailed: '로컬 모델을 설정하지 못했습니다.',
      quickstartStageEngine: '엔진', quickstartStageModel: '모델', quickstartStageFinish: '완료', useAction: '사용', activePill: '기본값', updateTitle: '엔진 업데이트 사용 가능', updateDetail: (next, current) => `새 llama.cpp 빌드(${next})를 설치할 수 있습니다. 현재 버전은 ${current}입니다. 다운로드 중에도 모델을 계속 사용할 수 있습니다.`, updateAction: '엔진 업데이트', updating: '엔진 업데이트 중…', upToDateTitle: '최신 엔진', upToDateDetail: (tag, backend) => `llama.cpp ${tag} (${backend}) 실행 중`, activeDetail: '새 채팅은 이 모델을 사용합니다. 첫 메시지를 보낼 때 모델을 불러옵니다.', activeNotLoaded: '첫 메시지를 보낼 때 불러옵니다.', loadedPill: '메모리에 로드됨',
      placementResident: 'GPU에서 전부 실행', placementSpilled: '일부를 RAM에서 실행', placementResidentTip: '이 컨텍스트 크기에서는 모두 GPU 메모리에서 실행되어 최고 속도를 냅니다.', placementSpilledTip: '모델 일부가 시스템 RAM에서 실행됩니다. 작동하지만 느립니다. 더 작은 모델이나 컨텍스트를 선택하면 전부 GPU 메모리에 들어갑니다.', loadingPill: '불러오는 중…', ejectTip: 'GPU 메모리 해제 (다음 메시지 때 다시 불러옵니다)', ejected: '모델을 내리고 GPU 메모리를 해제했습니다.', ejectFailed: '모델을 내리지 못했습니다.',
      stopServer: '끄기', startServer: '켜기', runtimeRunningDetail: '로컬 서버가 실행 중입니다. 끄면 GPU 메모리를 모두 비우며 다시 켤 때까지 새 채팅에서 로컬 모델을 사용하지 않습니다.', serverStopped: '로컬 서버를 중지하고 GPU 메모리를 해제했습니다.', serverStarted: '로컬 서버 실행 중', serverStopFailed: '로컬 서버를 중지하지 못했습니다.', serverStartFailed: '로컬 서버를 시작하지 못했습니다.', activating: '시작 중…', activateFailed: model => `${model} 모델로 전환하지 못했습니다.`, activateDoneToast: model => `새 채팅에서 ${model} 모델을 사용합니다.`,
      downloadFailed: model => `${model} 다운로드 실패`, downloadPauseFailed: model => `${model} 다운로드를 일시 정지하지 못했습니다.`, downloadResumeFailed: model => `${model} 다운로드를 계속하지 못했습니다.`, pillFitsGpu: 'GPU에 맞음', pillUsesRam: '시스템 RAM 사용', pillTooBig: '이 컴퓨터에 너무 큼',
      browseTitle: '모델 더 찾아보기', browseHint: 'Hugging Face 전체에서 검색합니다. 다운로드하는 모델은 이 컴퓨터 사양에 맞춰 크기를 정하지만 Hermes에서 검증하지는 않았습니다.', browsePlaceholder: '모델 이름 또는 작성자로 검색…', browseSearching: 'Hugging Face 검색 중', browseListing: '모델 파일 확인 중', browseShowFiles: '파일 표시', browseRefresh: '새로고침', browseDownloads: '다운로드', browseLikes: '좋아요', browseGated: 'Hugging Face 로그인 필요', browseNoGguf: '호환되는 모델 파일이 없습니다.', browseFitUnknown: '적합 여부 알 수 없음', browseAlreadyDownloaded: '이미 다운로드됨', addedByYou: '직접 추가함', browseDownloadStarted: '{name} 다운로드 중', browseDownloadAria: '{name} 다운로드',
      sideloadButton: '모델 파일 추가', sideloadTitle: 'GGUF 모델 파일 선택', sideloadDone: '{name} 추가 완료', sideloadAlreadyPresent: '이미 라이브러리에 있습니다.', pillFullContext: max => `전체 ${max} 컨텍스트`, pillFullContextTip: '처음부터 모델의 전체 컨텍스트 크기로 실행합니다.', pillUpTo: max => `최대 ${max} 컨텍스트`, pillGrowsTip: '대화에 더 많은 공간이 필요하면 자동으로 확장합니다.', pillVision: '이미지 인식', deleteAction: '모델 삭제', deleteConfirm: model => `${model}을(를) 디스크에서 삭제할까요?`, deleted: model => `${model} 삭제 완료`, deleteFailed: '삭제하지 못했습니다.'
    },
    billing: {
      freeTier: { footnote: '무료 티어에는 잔액이나 결제할 금액이 없습니다. Nous 계정으로 로그인하면 결제 및 사용량 정보가 표시됩니다.', plan: '무료 티어', model: '모델', connectors: '연결', included: '포함됨' },
      amountValidation: {
        reloadTo: '충전 목표액', greaterThanThreshold: '충전 목표액은 기준액보다 커야 합니다.', decimal: label => `${label}: 소수점 아래 두 자리까지의 금액을 입력하세요.`, positive: label => `${label}: 0보다 큰 금액을 입력하세요.`, minimum: (label, amount) => `${label}: 최소 금액은 ${amount}입니다.`, maximum: (label, amount) => `${label}: 최대 금액은 ${amount}입니다.`
      },
      stepUp: { openVerification: '인증 페이지 열기', dismiss: '닫기', waiting: '인증 링크를 기다리는 중…', verify: '인증하고 계속', deniedTitle: '인증이 승인되지 않았습니다.', deniedBody: '인증이 완료되었지만 이 터미널의 원격 결제는 허용되지 않았습니다.', successTitle: '인증 완료', successBody: '이 터미널에서 원격 결제를 사용할 수 있습니다.' },
      charge: {
        added: amount => amount ? `$${amount} 추가됨` : '크레딧 추가됨', failedTitle: '결제 실패', unconfirmedTitle: '결제 결과를 확인할 수 없습니다.', unconfirmedBody: message => `${message} 마지막 결제 결과를 확인할 수 없습니다. 다시 시도하기 전에 잔액과 내역을 확인하세요.`,
        checkTitle: '결제를 확인할 수 없습니다.', checkBody: '결제를 확인하지 못했습니다.', untrackedTitle: '결제를 추적할 수 없습니다.', untrackedBody: '결제 서비스에서 요청을 수락했지만 결제 ID를 반환하지 않았습니다.', timeoutTitle: '5분이 지나도 처리 중입니다.', timeoutBody: '결제가 계속 진행 중일 수 있습니다. 다시 시도하기 전에 포털에서 확인하세요.',
        authenticationRequired: '은행에서 인증을 요청합니다 (3DS). 구매를 완료하려면 포털에서 인증하세요.', expired: '카드가 만료되었습니다. 포털에서 카드를 업데이트하세요.', declined: '카드 결제가 거부되었습니다. 포털에서 다른 카드를 사용하세요.', failedBody: reason => `결제하지 못했습니다 (${reason}).`
      },
      preview: '미리 보기', summary: { balance: '잔액', plan: '요금제', autoRefill: '자동 충전' }, sections: { invoices: '청구서', plan: '요금제', paymentAndCredits: '결제 및 크레딧', usage: '사용량' }, usage: { title: '사용량' },
      buyCredits: { customAmount: '크레딧 금액 직접 입력', title: '지금 크레딧 구매', buyButton: '구매', processing: '처리 중… 결제 완료 확인', added: amount => `${amount} 추가됨. 잔액을 새로고침하고 있습니다.`, retry: '다시 시도', openPortal: '포털 열기' },
      plan: {
        title: '요금제', changePlan: '요금제 변경', viewPlans: '요금제 보기', backAria: '결제 화면으로 돌아가기', current: '현재 요금제', scheduled: '예약됨', empty: '현재 변경할 수 있는 요금제가 없습니다.', undo: '실행 취소', undoing: '취소 중…', downgrade: '하향 변경', confirmDowngrade: '요금제 하향 변경 확인', tryAgain: '다시 시도', checkingChange: '변경 사항 확인 중…', cannotChange: '여기서는 해당 변경을 할 수 없습니다.',
        alreadyOn: name => `이미 ${name} 요금제를 사용 중입니다. 변경할 내용이 없습니다.`, notScheduleable: '여기서는 해당 변경을 예약할 수 없습니다.', scheduling: '예약 중…', cancel: '취소',
        effectScheduled: (targetName, effectiveAt, creditsDelta) => `${targetName}(으)로 변경되며 ${effectiveAt}부터 적용됩니다. 지금은 청구되지 않으며 그때까지 현재 요금제가 유지됩니다.${creditsDelta ? ` 월간 크레딧 변경: ${creditsDelta}` : ''}`
      },
      autoReload: { threshold: '기준액', thresholdAria: '자동 충전 기준액', reloadTo: '충전 목표액', reloadToAria: '자동 충전 목표 금액', turnOffConfirm: '자동 충전을 끌까요?', turnOff: '끄기', disable: '사용 중지', updated: '자동 충전을 업데이트했습니다.', turnedOff: '자동 충전을 껐습니다.', manage: '관리', save: '저장', saving: '저장 중…', cancel: '취소' },
      state: {
        notice: { loggedOut: { title: 'Nous 계정 연결', message: 'Nous 계정으로 로그인하면 이곳에서 잔액, 요금제, 사용량을 확인할 수 있습니다.', action: '로그인' }, openPortal: '포털 열기 ↗', noCard: { title: '등록된 결제 수단 없음', message: '카드를 등록하기 전까지 크레딧 충전과 자동 충전을 사용할 수 없습니다. 포털에서 카드를 추가하세요.', action: '카드 추가 ↗' } },
        paymentMethod: { title: '결제 수단', description: '크레딧 충전과 구독 갱신에 사용할 카드를 관리합니다.', addAction: '결제 수단 추가', updateAction: '업데이트', provenance: { autoRefill: '자동 충전 카드', customerDefault: '기본 카드', subPin: '구독 카드', suffix: label => ` - ${label}` } },
        buyCredits: { description: '오늘 잔액에 추가되는 일회성 카드 결제입니다.' },
        autoRefill: { title: '잔액 부족 시 충전', genericDescription: '잔액이 기준액 아래로 떨어지면 크레딧을 자동으로 충전합니다.', offPill: '꺼짐', enabledPill: '사용', notAvailablePill: '—', manageCaption: '포털에서 자동 충전을 관리하세요.', turnOnCaption: '포털에서 자동 충전을 켜세요.', chargesDescription: (reloadTo, threshold) => `잔액이 ${threshold} 아래로 내려가면 ${reloadTo}을(를) 자동 충전합니다.`, distinctCardCaption: cardLabel => `자동 충전에는 ${cardLabel}을(를) 사용합니다. 포털에서 확인하세요.`, distinctCardFallback: '다른 카드', reconcileAction: '확인 ↗' },
        usage: {
          subscriptionCredits: { title: '구독 크레딧', barLabel: '남은 구독 크레딧', captionResets: date => `${date}에 초기화`, valueOf: (remaining, monthly) => `${monthly} 중 ${remaining} 남음`, valueOver: (remaining, monthly, over) => `${monthly} 중 ${remaining} 남음 · ${over} 초과` },
          topupCredits: { title: '충전 크레딧', caption: '만료되지 않음' }, monthlyCap: { title: '월간 지출 한도', barLabel: '사용한 월간 지출 한도', captionDefault: '기본 한도', captionSpending: '월간 원격 지출', valueUsed: (spent, limit) => `${limit} 중 ${spent} 사용` }
        },
        planCard: { freeTier: '무료', chooseAction: '선택 ↗', adjustPlanAction: '요금제 조정 ↗', unavailableCaption: '구독 세부 정보를 사용할 수 없지만 포털은 열 수 있습니다.', downgradeCaption: (tierName, when) => `${when}에 ${tierName}(으)로 변경됩니다.`, cancellationCaption: when => `${when}에 취소됩니다.`, renewsCaption: date => `${date} 갱신`, noSubscriptionCaption: '활성 구독이 없습니다. 유료 모델은 충전 크레딧을 사용합니다.' }
      },
      errors: {
        consentRequired: { title: '카드 확인 필요', message: '포털에서 이 카드를 터미널 결제용으로 확인하세요.' }, insufficientScope: { title: '원격 결제 승인 필요', message: '원격 결제를 허용해야 합니다. 크레딧을 충전하여 허용한 뒤 다시 시도하세요.' },
        remoteSpendingRevoked: { title: '원격 결제가 중지됨', messageByAdmin: '관리자가 이 터미널의 원격 결제를 중지했습니다.', messageBySelf: '이 터미널의 원격 결제를 중지했습니다.' }, remoteSpendingReconnect: who => `${who} 이 기기를 다시 인증하려면 설정 → 게이트웨이에서 다시 연결하세요.`,
        sessionRevoked: { title: '세션 로그아웃됨', message: '세션에서 로그아웃되었습니다. 설정 → 게이트웨이에서 다시 로그인하세요.' }, cliBillingDisabled: { title: '원격 결제 꺼짐', message: '이 계정의 원격 결제가 꺼져 있습니다. 결제 관리자가 포털의 Hermes Agent 페이지에서 켤 수 있습니다.' },
        roleRequired: { title: '관리자 권한 필요', message: '자금을 추가하려면 조직 관리자 또는 소유자 권한이 필요합니다. 관리자에게 요청하거나 포털에서 관리하세요.' }, idempotencyConflict: { title: '새로 충전 시작', message: '🔴 해당 결제 키를 다른 금액에 이미 사용했습니다. 새로 충전을 시작하세요.' },
        noPaymentMethod: { title: '저장된 카드 없음', message: '💳 아직 터미널 결제에 사용할 카드가 없습니다. 포털에서 등록하세요 (일회성 크레딧 구매 카드는 저장되지 않습니다).' }, orgAccessDenied: { title: '조직 접근 거부됨', message: '이 토큰은 관리 권한이 있는 조직에 연결되지 않았습니다.' },
        monthlyCapExceeded: { title: '월간 지출 한도 도달', messageReached: '🔴 월간 지출 한도에 도달했습니다.', messageHeadroom: remaining => `🔴 월간 지출 한도에 도달했습니다. 남은 한도는 $${remaining}입니다.` },
        rateLimited: { title: '현재 결제가 너무 많습니다.', message: mins => mins > 0 ? `🟡 현재 결제가 너무 많습니다 (약 ${mins}분 뒤 다시 시도하세요). 결제 실패는 아닙니다.` : '🟡 현재 결제가 너무 많습니다. 결제 실패는 아닙니다.' },
        stripeUnavailable: { title: 'Stripe에 문제가 있습니다.', message: mins => mins > 0 ? `Stripe에 문제가 있습니다. 약 ${mins}분 뒤 다시 시도하세요.` : 'Stripe에 문제가 있습니다. 잠시 후 다시 시도하세요.' },
        upgradeCapExceeded: { title: '일일 요금제 변경 한도 도달', message: '일일 요금제 변경 한도에 도달했습니다. 내일 다시 시도하세요.' }, endpointUnavailable: { title: '결제 엔드포인트를 사용할 수 없음', message: '결제 엔드포인트가 JSON이 아닌 응답을 반환했습니다. 이 배포 환경에서 사용할 수 없는 기능일 수 있습니다.' },
        timeout: { title: '결제 요청 시간 초과', message: '결제 요청 시간이 초과되었습니다.' }, transport: { title: '결제 연결 실패', message: '게이트웨이에 도달하기 전에 결제 요청이 실패했습니다.' }, default: { title: '결제 요청 실패', message: '결제 요청에 실패했습니다.' }
      }
    },
    screenshot: {
      enabledTitle: '스크린샷 단축키', enabledDesc: '어떤 앱에서든 Command 키 두 개를 함께 눌러 앞에 있는 창을 캡처하고 현재 Hermes 초안에 첨부합니다. 자동 전송하지 않습니다. 기본값은 꺼짐입니다.', statusTitle: '스크린샷 단축키 상태', checking: '스크린샷 단축키 확인 중…', disabled: '스크린샷 단축키가 꺼져 있습니다.', starting: '단축키 감지기를 시작하고 있습니다. 아직 사용할 수 없습니다.', ready: '단축키를 사용할 수 있습니다. 스크린샷은 전송되지 않고 현재 초안에 첨부됩니다.',
      inputPermission: '입력 모니터링 권한이 있으면 다른 앱을 사용하는 동안에도 Hermes가 Command 키 두 개를 감지할 수 있습니다. 시스템 설정 → 개인정보 보호 및 보안 → 입력 모니터링에서 Hermes를 허용하세요.', screenPermission: '화면 기록 권한이 있으면 이 단축키를 사용할 때 앞에 있는 앱 창을 캡처할 수 있습니다. 시스템 설정 → 개인정보 보호 및 보안 → 화면 기록에서 Hermes를 허용하세요.', openSettings: '시스템 설정 열기', retry: '다시 시도', unavailable: '스크린샷 단축키를 사용할 수 없습니다. 다시 시도하거나 기능을 끄세요.', errorTitle: '스크린샷 단축키 오류', loadFailed: '단축키 상태를 읽지 못했습니다. 다시 시도해 현재 설정을 확인하세요.', saveFailed: '단축키 변경을 확인하지 못했습니다. 다시 시도해 현재 설정을 확인하세요.', permissionFailed: '시스템 설정을 열지 못했습니다. 개인정보 보호 및 보안에서 직접 열고 다시 시도하세요.', captureFailed: '앞에 있는 창을 캡처하지 못했습니다. 아무것도 첨부하거나 보내지 않았습니다.', contextChanged: '캡처하는 동안 현재 초안이 바뀌었습니다. 스크린샷을 첨부하거나 보내지 않았습니다.'
    },
    hudModifier: {
      title: '탭하여 HUD 열기', description: 'Mac에서는 ⌘ + Option, Windows/Linux에서는 Ctrl + Alt를 눌렀다 떼면 어느 앱에서든 HUD가 앞으로 나옵니다. 기본값은 꺼짐이며 이 기기에만 적용됩니다.',
      permission: '시스템 설정 → 개인정보 보호 및 보안 → 입력 모니터링에서 Hermes를 허용한 뒤 다시 시도하세요. 이 동작은 키 입력을 기록하거나 화면을 캡처하지 않습니다.', unavailable: 'HUD 제스처 도우미를 시작하지 못했거나 예기치 않게 중지되었습니다. 다시 시도하거나 Hermes를 다시 시작하세요. Hermes 안에서 사용하는 기존 HUD 단축키는 계속 작동합니다.', missingHelper: '이 Hermes 설치에 HUD 제스처 도우미가 없습니다. Hermes를 업데이트하거나 다시 설치한 뒤 시도하세요.', unsupportedSession: '이 데스크톱 세션에서는 전역 보조 키 감지를 지원하지 않습니다. Linux는 X11이 필요하며 Wayland는 지원하지 않습니다.'
    },
    connections: { kindCloud: 'Hermes Cloud', kindSsh: 'SSH', labelPlaceholder: '홈 랩', sameBackendHint: label => `“${label}”과(와) 같은 백엔드`, localAddHint: '관리형 로컬 연결이 이미 있습니다. 로컬 연결은 하나만 사용할 수 있습니다.' },
    managedUpdates: { sshConnection: 'Desktop에서 관리하는 SSH 설치', receipt: (id, outcome) => `영수증 ${id} · ${outcome}`, receiptVersions: (pre, post) => `${pre} → ${post}`, scopesRestored: profiles => `복원된 프로필: ${profiles}`, scopeNotRestored: (profile, error) => `프로필 “${profile}”을(를) 복원하지 못했습니다: ${error}` },
    poolLimits: { warmBotBackendsAria: '봇 백엔드 미리 준비', warmBotBackendsTitle: '봇 백엔드 미리 준비', backendIdleTimeoutAria: '백엔드 유휴 시간 제한 (밀리초)', backendIdleTimeoutTitle: '백엔드 유휴 시간 제한' },
    uninstallSection: { managedBody: '시스템에서 관리하는 설치이므로 Hermes가 직접 제거할 수 없습니다.', dataKept: path => `설정, 채팅, 비밀 정보는 ${path}에 있습니다. 앱을 제거해도 삭제되지 않습니다.`, openAppsSettings: '앱 설정 열기' },
    computerUse: { accessibility: '손쉬운 사용', screenRecording: '화면 기록', driverHealth: '드라이버 상태' },
    gateway: {
      envOverride: '환경 변수 재정의', cloudTitle: 'Hermes Cloud', cloudSignInTitle: 'Hermes Cloud', cloudNoAgents: { linkText: 'Nous 포털' }, cloudSavedTitle: '저장된 클라우드 게이트웨이',
      cloudSavedDesc: '기본값을 바꾸지 않고 저장된 게이트웨이를 사용합니다. 아래에서 로그인해 인스턴스를 추가하세요. 저장된 연결 목록에서 이름과 로그인을 관리할 수 있습니다.', cloudUseSaved: '게이트웨이 사용', cloudActive: '이 창에서 사용 중', savedToken: '저장됨',
      sshHostCustom: '직접 입력…', sshUserPlaceholder: '~/.ssh/config에서 가져옴', sshKeyTitle: '키 파일', sshHermesPathPlaceholder: '자동 감지',
      sshErrInteractiveAuth: 'Tailscale SSH는 대화형 브라우저 확인이 필요합니다. 터미널에서 `ssh <host> true`를 실행하고 확인을 마친 뒤 다시 시도하세요. Hermes가 백그라운드에서 SSH를 실행합니다.'
    },
    mcp: {
      capabilitySummary: (tools, prompts, resources) => [`도구 ${tools}개`, ...(prompts ? [`프롬프트 ${prompts}개`] : []), ...(resources ? [`리소스 ${resources}개`] : [])].join(' · '),
      costTokens: tokens => `통화당 ~${tokens} 토큰`, usage30d: uses => `30일간 ${uses}회 사용`, authenticatedMessage: (server, count) => `${server}: 도구 ${count}개`,
      deepLinkErrorTitle: 'MCP 설치 링크 거부됨', deepLinkErrorName: '링크의 서버 이름이 없거나 올바르지 않습니다.', deepLinkErrorConfig: '링크 설정이 올바른 Base64 인코딩 JSON이 아닙니다.', deepLinkErrorShape: '설정은 문자열 `url` 또는 `command` 필드가 있는 JSON 객체여야 합니다.', deepLinkErrorUrl: 'http:// 및 https:// 서버 URL만 허용됩니다.', deepLinkErrorTooLarge: '설정 데이터가 32KB 제한을 초과합니다.'
    },
    fieldLabels: defineFieldCopy({
      toolsets: '활성화된 도구 모음', agent: { apiMaxRetries: 'API 재시도 횟수', serviceTier: '서비스 등급', toolUseEnforcement: '도구 사용 강제' },
      terminal: { backend: '실행 백엔드', timeout: '명령 시간 제한', dockerImage: 'Docker 이미지', singularityImage: 'Singularity 이미지', modalImage: 'Modal 이미지', daytonaImage: 'Daytona 이미지' },
      toolOutput: { maxBytes: '터미널 출력 제한', maxLines: '파일 페이지 제한', maxLineLength: '줄 길이 제한' }, approvals: { mcpReloadConfirm: 'MCP 다시 불러오기 확인' },
      commandAllowlist: '명령 허용 목록', security: { allowPrivateUrls: '비공개 URL 허용' }, browser: { allowPrivateUrls: '브라우저 비공개 URL', autoLocalForPrivateUrls: '비공개 URL에 로컬 브라우저 사용', useRealProfile: '실제 브라우저 프로필 사용' },
      checkpoints: { maxSnapshots: '체크포인트 제한' }, voice: { maxRecordingSeconds: '최대 녹음 시간', autoTts: '응답 소리 내어 읽기', voiceChatMode: '음성 대화 모드', gptLive: { voice: 'GPT-Live 음성', instructions: 'GPT-Live 페르소나' } },
      stt: {
        enabled: '음성 텍스트 변환', echoTranscripts: '전사 결과 표시', provider: '음성 인식 공급자', streaming: '실시간 전사', local: { model: '로컬 전사 모델', language: '전사 언어' },
        openai: { model: 'OpenAI STT 모델', streamingModel: 'OpenAI 실시간 전사 모델' }, groq: { model: 'Groq STT 모델' }, mistral: { model: 'Mistral STT 모델' }, xai: { model: 'xAI STT 모델' }, deepinfra: { model: 'DeepInfra STT 모델' },
        elevenlabs: { modelId: 'ElevenLabs STT 모델', languageCode: 'ElevenLabs 언어', tagAudioEvents: '오디오 이벤트 태그', diarize: '화자 구분' }
      },
      tts: {
        provider: '텍스트 음성 변환 공급자', edge: { voice: 'Edge 음성' }, openai: { model: 'OpenAI TTS 모델', voice: 'OpenAI 음성' }, elevenlabs: { voiceId: 'ElevenLabs 음성', modelId: 'ElevenLabs 모델' },
        xai: { voiceId: 'xAI (Grok) 음성 ID', language: 'xAI 언어', speed: 'xAI 재생 속도', autoSpeechTags: 'xAI 자동 음성 태그', optimizeStreamingLatency: 'xAI 스트리밍 지연 최적화', sampleRate: 'xAI 샘플 레이트', bitRate: 'xAI 비트 레이트' },
        minimax: { model: 'MiniMax TTS 모델', voiceId: 'MiniMax 음성' }, mistral: { model: 'Mistral TTS 모델', voiceId: 'Mistral 음성' }, gemini: { model: 'Gemini TTS 모델', voice: 'Gemini 음성' },
        neutts: { model: 'NeuTTS 모델', device: 'NeuTTS 장치' }, kittentts: { model: 'KittenTTS 모델', voice: 'KittenTTS 음성' }, piper: { voice: 'Piper 음성' }, deepinfra: { model: 'DeepInfra TTS 모델', voice: 'DeepInfra 음성' }
      },
      memory: { memoryCharLimit: '메모리 용량', userCharLimit: '프로필 용량', provider: '메모리 공급자' },
      compression: { enabled: '자동 압축', threshold: '압축 기준', codexGpt55Autoraise: 'Codex 압축 자동 상향', targetRatio: '압축 목표 비율', protectLastN: '보호할 최근 메시지 수' }
    }),
    fieldDescriptions: defineFieldCopy({
      browser: { useRealProfile: '로컬 탐색에서 실제 로그인을 사용합니다. Hermes가 기본 브라우저 프로필(쿠키, 로그인, 환경설정)을 관리되는 스냅샷에 복사한 뒤 패키지된 Chromium으로 제어합니다. 실제 프로필을 직접 열지 않으며 실행할 때마다 스냅샷을 갱신합니다. 클라우드 브라우저 백엔드를 설정해도 요청에 따라 실제 프로필의 로컬 세션을 열 수 있습니다. Chromium 기반 브라우저(Chrome, Edge, Brave, Brave Origin, Chromium)만 지원하며 다른 브라우저를 기본값으로 지정하면 안내와 함께 실패합니다. 기본값은 꺼짐입니다.' },
      terminal: { dockerImage: '실행 백엔드가 Docker일 때 사용할 컨테이너 이미지입니다.', singularityImage: '실행 백엔드가 Singularity일 때 사용할 이미지입니다.', modalImage: '실행 백엔드가 Modal일 때 사용할 이미지입니다.', daytonaImage: '실행 백엔드가 Daytona일 때 사용할 이미지입니다.' },
      compression: { enabled: '대화가 길어지면 이전 컨텍스트를 요약합니다.', codexGpt55Autoraise: '지원되는 ChatGPT Codex OAuth 모델에서 압축률을 85%로 높입니다.' },
      auxiliary: { compression: { timeout: '보조 압축 모델 호출을 기다리는 시간(초, 기본값 120)입니다. 로컬 모델이 느리면 늘리세요.' } },
      voice: {
        autoTts: '어시스턴트 응답을 자동으로 음성으로 읽습니다.',
        voiceChatMode: 'chained: 아래 공급자를 사용해 음성 인식 → Hermes → 음성 합성으로 처리합니다. gpt-live: 양방향 OpenAI 음성 모델(gpt-live-1)이 듣고 말하며 실제 요청은 모두 Hermes에 전달합니다. 선택한 모델이 전체 도구를 사용해 답변합니다. OpenAI API 키가 필요하며 음성 기능은 분당 $0.05가 청구됩니다.',
        gptLive: { voice: 'GPT-Live 모드에서 사용할 음성입니다. 사용자 지정 음성 ID를 사용할 수 있습니다.', instructions: '실시간 음성 페르소나의 어조, 속도, 언어에 관한 추가 문장입니다. Hermes는 자체 시스템 프롬프트를 유지합니다.' }
      },
      tts: { xai: {
        voiceId: 'xAI 음성 ID(예: eve) 또는 사용자 지정 음성 ID입니다.', language: '음성 언어 코드(예: en, pt-BR) 또는 자동 감지를 위한 "auto"입니다.', speed: '재생 속도입니다. 0.7은 느림, 1.0은 보통, 1.5는 빠름입니다.',
        autoSpeechTags: '합성 전에 LLM이 스크립트에 표현 오디오 태그([laughing], [sighs])를 삽입하도록 허용합니다.', optimizeStreamingLatency: '지연 시간과 품질의 균형입니다. 0은 최고 품질, 2는 최저 지연 시간입니다.', sampleRate: '오디오 샘플 레이트(Hz)입니다. 높을수록 품질이 좋지만 파일 크기도 커집니다.', bitRate: 'MP3 비트레이트(bps)입니다. 코덱이 mp3일 때만 적용됩니다.'
      }, neutts: { device: 'NeuTTS의 로컬 추론 장치입니다.' } },
      stt: { enabled: '로컬 또는 공급자 기반 음성 전사를 사용합니다.', echoTranscripts: '음성 메시지의 원본 🎙️ 전사 내용을 채팅에 표시합니다.', streaming: '말하는 동안 텍스트를 표시합니다 (OpenAI, xAI, ElevenLabs). 실패하면 녹음 방식으로 전환합니다.', elevenlabs: { languageCode: '선택 사항인 ISO-639-3 언어 코드입니다. 비워 두면 ElevenLabs가 자동 감지합니다.' } },
      updates: { nonInteractiveLocalChanges: '터미널 프롬프트 없이 앱에서 Hermes를 업데이트할 때 로컬 소스 변경 사항을 임시 보관하거나 버립니다. 터미널에서 업데이트하면 항상 확인합니다.' }
    })
  }
}
