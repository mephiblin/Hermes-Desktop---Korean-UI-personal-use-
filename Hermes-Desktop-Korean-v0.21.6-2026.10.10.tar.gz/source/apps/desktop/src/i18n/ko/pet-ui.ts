export const petUiEn = {
  noImageBackend: 'Add an image backend to generate',
  referenceProviderNeeded: 'Hatching a custom pet needs a provider that can ground on a reference image.',
  setupImages: 'Set up image generation',
  getKeyFrom: 'Grab a key from',
  reference: 'Reference',
  removeReference: 'Remove reference',
  addReference: 'Add a reference',
  messagePlaceholder: 'Message…',
  openInHermes: 'Open in Hermes',
  learned: 'learned',
  hatchingProgress: 'Hatching progress',
  hub: 'hub'
}
export const petUiKo: typeof petUiEn = {
  noImageBackend: '생성하려면 이미지 백엔드를 추가하세요',
  referenceProviderNeeded: '새 마스코트를 만들려면 참조 이미지를 활용할 수 있는 이미지 생성 공급자가 필요합니다.',
  setupImages: '이미지 생성 설정',
  getKeyFrom: 'API 키 발급처:',
  reference: '참조 이미지',
  removeReference: '참조 이미지 제거',
  addReference: '참조 이미지 추가',
  messagePlaceholder: '메시지 입력…',
  openInHermes: 'Hermes에서 열기',
  learned: '학습됨',
  hatchingProgress: '마스코트 생성 진행률',
  hub: '허브'
}
