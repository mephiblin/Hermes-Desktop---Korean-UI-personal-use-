import { describe, expect, it } from 'vitest'

import { BOTS_LOCALES } from '../plugins/hermes-bots/i18n'
import { KANBAN_LOCALES } from '../plugins/kanban/i18n'

import { registerPluginLocales, translatePlugin } from './plugin-i18n'

function leaves(value: unknown, prefix = ''): Array<[string, unknown]> {
  if (value && typeof value === 'object') {
    return Object.entries(value).flatMap(([key, child]) => leaves(child, prefix ? `${prefix}.${key}` : key))
  }

  return [[prefix, value]]
}

describe.each([['bots', BOTS_LOCALES], ['kanban', KANBAN_LOCALES]] as const)('%s Korean plugin', (name, bundles) => {
  it('provides every key explicitly and preserves interpolation', () => {
    const english = new Map(leaves(bundles.en))
    const korean = new Map(leaves(bundles.ko))
    expect([...korean.keys()].sort()).toEqual([...english.keys()].sort())

    for (const [path, value] of english) {
      const translated = korean.get(path)
      expect(typeof translated, path).toBe(typeof value)

      if (typeof value !== 'function' || typeof translated !== 'function') {continue}
      const args = Array.from({ length: value.length }, (_, i) => `⟦${i}⟧`)
      let original: string

      try { original = JSON.stringify(value(...args)) } catch { continue }
      const localized = JSON.stringify(translated(...args))

      for (const arg of args.filter(arg => original.includes(arg))) {expect(localized, path).toContain(arg)}
    }
  })

  it('resolves Korean through the real plugin locale registry', () => {
    const id = `korean-pack-test-${name}`
    const dispose = registerPluginLocales(id, bundles)

    try {
      for (const [key, value] of leaves(bundles.ko)) {
        if (typeof value !== 'string') {continue}
        expect(translatePlugin(id, 'ko', key, []), key).toBe(value)
      }
    } finally { dispose() }
  })
})
