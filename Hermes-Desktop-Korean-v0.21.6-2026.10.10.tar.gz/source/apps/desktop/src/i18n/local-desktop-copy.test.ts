import { expect, it } from 'vitest'

import { desktopCopy } from './local-desktop-copy'
import { translateFrom } from './runtime'

function leaves(value: unknown, prefix = ''): Array<[string, unknown]> {
  if (value && typeof value === 'object' && !Array.isArray(value)) {
    return Object.entries(value).flatMap(([key, child]) => leaves(child, prefix ? `${prefix}.${key}` : key))
  }

  return [[prefix, value]]
}

it('localizes supplemental renderer copy and preserves English behavior for other languages', () => {
  const english = new Map(leaves(desktopCopy.en))
  const korean = new Map(leaves(desktopCopy.ko))
  expect([...korean.keys()].sort()).toEqual([...english.keys()].sort())

  for (const [key, value] of english) {
    const translated = korean.get(key)
    expect(typeof translated, key).toBe(typeof value)
    const args = typeof value === 'function' ? Array.from({ length: value.length }, (_, i) => `⟦${i}⟧`) : []
    const resolve = (locale: string) => translateFrom(id => id === 'ko' ? desktopCopy.ko : desktopCopy.en, locale, key, args)
    const original = resolve('en')
    const localized = resolve('ko')

    // MoA is a model-composition identifier, kept verbatim in every locale.
    if (key === 'settings.model.moaPrefix') {expect(localized).toBe('MoA:')}
    else {expect(localized, key).toMatch(/[가-힣]/)}

    expect(resolve('ja'), key).toBe(original)

    if (typeof value === 'function' && typeof translated === 'function') {
      expect(translated.length, key).toBe(value.length)

      for (const arg of args.filter(arg => original.includes(arg))) {expect(localized, key).toContain(arg)}
    }
  }
})
