import { useCallback } from 'react'

import { useI18n } from './context'
import { chatUiEn, chatUiKo } from './ko/chat-ui'
import { petUiEn, petUiKo } from './ko/pet-ui'
import { translateFrom } from './runtime'
import { settingsUiEn, settingsUiKo } from './settings-ui'

// Local Korean-pack additions for formerly inline English renderer copy.
// Other languages retain the same English copy they displayed before.
export const desktopCopy = {
  en: { chat: chatUiEn, pet: petUiEn, ...settingsUiEn },
  ko: { chat: chatUiKo, pet: petUiKo, ...settingsUiKo }
}

export function useDesktopCopy() {
  const { locale } = useI18n()

  return useCallback((key: string, ...args: unknown[]) =>
    translateFrom(id => id === 'ko' ? desktopCopy.ko : desktopCopy.en, locale, key, args), [locale])
}
