export const settingsUiEn = {
  settings: {
    quickEntryWindow: {
      windowLabel: 'Quick Entry',
      promptPlaceholder: 'Ask Hermes…',
      disconnectedPlaceholder: 'Not connected — open Hermes to reconnect',
      sendTo: 'Send to',
      targetLabel: 'Target session',
      currentChat: 'Current chat',
      newSession: 'New session',
      deliveryFailed: 'Hermes could not deliver the prompt.'
    },
    computerUse: {
      checking: 'Checking Computer Use status…',
      unsupported: (platform: string) => `Computer Use isn’t supported on this platform (${platform}).`,
      installDriver: 'Install the cua-driver backend below to drive this machine.',
      grantPermissionHint: 'Then grant Accessibility and Screen Recording here.',
      grantIdentity: 'Grants attach to CuaDriver’s own identity (com.trycua.driver), not Hermes — so the dialog is attributed to the process that drives your Mac.',
      recheck: 'Recheck',
      ready: 'Computer Use is ready. Ask the agent to capture an app and click around.',
      waitingApproval: 'Waiting for approval…',
      grantPermissions: 'Grant permissions',
      permissionHints: {
        accessibility: 'Lets cua-driver post clicks, keystrokes, and read the accessibility tree.',
        screenRecording: 'Lets cua-driver capture screenshots of app windows.'
      },
      permissionStatus: { granted: 'Granted', notGranted: 'Not granted', unknown: 'Unknown' },
      readyStatus: 'Ready', notReadyStatus: 'Not ready',
      linuxNote: 'Drives your desktop via the X11/XWayland accessibility stack — no permission prompt.',
      windowsNote: 'First run may trigger a Windows SmartScreen prompt for the cua-driver UIAccess worker — allow it.'
    },
    poolLimits: {
      warmBotBackendsHelp: 'How many bot backends stay running for instant switching. Higher = faster switches, more memory (~60MB per backend). Applies immediately.',
      backendIdleTimeoutHelp: 'How long an unused remote bot connection stays cached before it is dropped. Local backends keep running while idle, since they run cron jobs and bot chats.'
    },
    memory: {
      providerConfig: {
        waitingConsent: 'Waiting for browser consent…',
        connect: 'Connect', connectOAuth: 'Connect via OAuth', reconnect: 'Reconnect', cancel: 'Cancel', apiKeySet: 'API key set', oauthSet: 'OAuth set',
        connectStartFailed: 'Could not start the connection.', connectFailedTitle: 'Failed to start connection', timedOut: 'Timed out — try again.', connectionFailed: 'Connection failed.',
        updated: 'Memory provider configuration updated.', saveFailed: (label: string) => `Failed to save ${label} settings`,
        fullConfiguration: 'full configuration',
        description: (provider: string, profile: string) => `Every ${provider} option for the ${profile} profile. Blank fields fall back to the resolved host or built-in default.`,
        configurationReference: (provider: string) => `${provider} configuration reference`,
        saveChanges: 'Save changes',
        aboutField: (label: string) => `About ${label}`,
        keepCurrentSecret: 'Leave blank to keep current value', set: 'set',
        loadFailed: (error: string) => `Memory provider settings failed to load: ${error}`,
        retry: 'Retry', loading: 'Loading memory provider settings…',
        settings: (provider: string) => `${provider} settings`,
        secretSet: (label: string) => `${label} set`, secretNotSet: (label: string) => `${label} not set`,
        fullConfig: 'Full config…'
      }
    },
    appearance: {
      marketplaceHeading: 'From the VS Code Marketplace',
      noInstalledThemes: (query: string) => `No installed themes match “${query}”.`
    },
    billing: {
      previewFixtureLabel: 'Billing preview fixture (dev only)',
      previewLive: 'live'
    },
    model: { moaPresetHeading: 'MoA presets', moaPrefix: 'MoA:' },
    windowControls: { group: 'Window controls', minimize: 'Minimize window', restore: 'Restore window', maximize: 'Maximize window', close: 'Close window' }
  },
  starmap: {
    nodeMenu: {
      editSkill: 'Edit skill…', editMemory: 'Edit memory…', archiveSkill: 'Archive skill', deleteMemory: 'Delete memory',
      editTitle: (label: string) => `Edit ${label}`, deleteMemoryTitle: (label: string) => `Delete ${label}?`, removedPermanently: 'This memory is removed permanently.'
    },
    timeline: { scrubber: 'Timeline scrubber', pause: 'Pause', play: 'Play timeline' },
    legend: { skill: 'skill', memory: 'memory', age: 'core = oldest · outer = newer' }
  }
} as const

export const settingsUiKo = {
  settings: {
    quickEntryWindow: {
      windowLabel: '빠른 입력',
      promptPlaceholder: 'Hermes에게 요청…',
      disconnectedPlaceholder: '연결되지 않음 — 다시 연결하려면 Hermes를 여세요',
      sendTo: '보낼 대상',
      targetLabel: '대상 세션',
      currentChat: '현재 채팅',
      newSession: '새 세션',
      deliveryFailed: 'Hermes가 요청을 전달하지 못했습니다.'
    },
    computerUse: {
      checking: 'Computer Use 상태 확인 중…',
      unsupported: (platform: string) => `이 플랫폼에서는 Computer Use를 지원하지 않습니다 (${platform}).`,
      installDriver: '이 컴퓨터를 제어하려면 아래에서 cua-driver 백엔드를 설치하세요.',
      grantPermissionHint: '그런 다음 여기에서 손쉬운 사용 및 화면 기록 권한을 허용하세요.',
      grantIdentity: '권한은 Hermes가 아니라 CuaDriver 고유 ID(com.trycua.driver)에 부여되므로 권한 대화상자에 Mac을 제어하는 프로세스가 표시됩니다.',
      recheck: '다시 확인',
      ready: 'Computer Use를 사용할 수 있습니다. 에이전트에 앱 화면을 캡처하고 조작해 달라고 요청하세요.',
      waitingApproval: '승인 대기 중…',
      grantPermissions: '권한 부여',
      permissionHints: {
        accessibility: 'cua-driver가 클릭과 키 입력을 보내고 손쉬운 사용 트리를 읽도록 허용합니다.',
        screenRecording: 'cua-driver가 앱 창의 스크린샷을 캡처하도록 허용합니다.'
      },
      permissionStatus: { granted: '허용됨', notGranted: '허용되지 않음', unknown: '알 수 없음' },
      readyStatus: '준비됨', notReadyStatus: '준비되지 않음',
      linuxNote: 'X11/XWayland 손쉬운 사용 스택으로 데스크톱을 제어합니다. 권한 대화상자는 표시되지 않습니다.',
      windowsNote: '처음 실행하면 cua-driver UIAccess 작업자에 대해 Windows SmartScreen 안내가 표시될 수 있습니다. 허용하세요.'
    },
    poolLimits: {
      warmBotBackendsHelp: '빠르게 전환할 수 있도록 계속 실행할 봇 백엔드 수입니다. 수를 늘리면 전환이 빨라지지만 메모리를 더 사용합니다 (백엔드당 약 60MB). 즉시 적용됩니다.',
      backendIdleTimeoutHelp: '사용하지 않는 원격 봇 연결을 종료하기 전까지 캐시에 보관하는 시간입니다. 로컬 백엔드는 예약 작업과 봇 채팅을 실행하므로 유휴 상태에서도 계속 작동합니다.'
    },
    memory: {
      providerConfig: {
        waitingConsent: '브라우저 승인을 기다리는 중…',
        connect: '연결', connectOAuth: 'OAuth로 연결', reconnect: '다시 연결', cancel: '취소', apiKeySet: 'API 키 설정됨', oauthSet: 'OAuth 설정됨',
        connectStartFailed: '연결을 시작하지 못했습니다.', connectFailedTitle: '연결 시작 실패', timedOut: '시간이 초과되었습니다. 다시 시도하세요.', connectionFailed: '연결하지 못했습니다.',
        updated: '메모리 공급자 설정을 업데이트했습니다.', saveFailed: (label: string) => `${label} 설정을 저장하지 못했습니다.`,
        fullConfiguration: '전체 설정',
        description: (provider: string, profile: string) => `${profile} 프로필의 ${provider} 옵션 전체입니다. 비워 둔 항목은 확인된 호스트 설정이나 내장 기본값을 사용합니다.`,
        configurationReference: (provider: string) => `${provider} 설정 문서`,
        saveChanges: '변경 사항 저장',
        aboutField: (label: string) => `${label} 정보`,
        keepCurrentSecret: '현재 값을 유지하려면 비워 두세요', set: '설정됨',
        loadFailed: (error: string) => `메모리 공급자 설정을 불러오지 못했습니다: ${error}`,
        retry: '다시 시도', loading: '메모리 공급자 설정 불러오는 중…',
        settings: (provider: string) => `${provider} 설정`,
        secretSet: (label: string) => `${label} 설정됨`, secretNotSet: (label: string) => `${label} 설정되지 않음`,
        fullConfig: '전체 설정…'
      }
    },
    appearance: {
      marketplaceHeading: 'VS Code Marketplace에서',
      noInstalledThemes: (query: string) => `“${query}”에 맞는 설치된 테마가 없습니다.`
    },
    billing: {
      previewFixtureLabel: '결제 미리 보기 샘플 (개발 전용)',
      previewLive: '실시간'
    },
    model: { moaPresetHeading: 'MoA 프리셋', moaPrefix: 'MoA:' },
    windowControls: { group: '창 컨트롤', minimize: '창 최소화', restore: '창 복원', maximize: '창 최대화', close: '창 닫기' }
  },
  starmap: {
    nodeMenu: {
      editSkill: '스킬 편집…', editMemory: '메모리 편집…', archiveSkill: '스킬 보관', deleteMemory: '메모리 삭제',
      editTitle: (label: string) => `${label} 편집`, deleteMemoryTitle: (label: string) => `${label} 메모리를 삭제할까요?`, removedPermanently: '이 메모리는 영구 삭제됩니다.'
    },
    timeline: { scrubber: '타임라인 탐색 막대', pause: '일시 정지', play: '타임라인 재생' },
    legend: { skill: '스킬', memory: '메모리', age: '중심은 오래된 항목 · 바깥쪽은 새로운 항목' }
  }
} as const
