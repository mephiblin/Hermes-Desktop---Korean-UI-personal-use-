import { parseMediaGuard } from '@/lib/media-reaction-guard'
import { skillInvocationText } from '@hermes/shared'

import { splitLeadingAttachmentRefs } from '@/components/assistant-ui/reference-kinds'
import { extractImageRefs } from '@/lib/embedded-images'
import { parseErrorSurface } from '@/lib/error-surface'
import { dedupeGeneratedImageEchoesInParts } from '@/lib/generated-images'
import { isTodoToolName } from '@/lib/todos'
import type { MessageReaction, SessionMessage } from '@/types/hermes'

import {
  assistantTextPart,
  chatMessageText,
  dedupeRepeatedTextInParts,
  reasoningPart,
  reasoningTextFromDetails,
  renderMediaTags,
  textPart
} from './parts'
import {
  applyStoredToolResult,
  applyStoredToolResultToParts,
  storedToolMessagePart,
  textFromUnknown,
  toolPartFromStoredCall,
  withUniqueToolCallIds
} from './tool-parts'
import type { ChatMessage, ChatMessagePart } from './types'

const ATTACHED_CONTEXT_MARKER_RE = /(?:^|\n)--- Attached Context ---\s*\n/
// A background-process heartbeat wake persisted by a backend older than the
// one that types those rows `display_kind=hidden`. It is model scaffolding,
// not something the user wrote, so it never paints as a bubble.
const LEGACY_HEARTBEAT_ROW_RE = /^\[Background process \S+ heartbeat #\d+ /
const CONTEXT_WARNINGS_MARKER_RE = /(?:^|\n)--- Context Warnings ---[\s\S]*$/
const CONTEXT_REF_RE = /@(file|folder|url|image|tool|terminal):(?:"[^"\n]+"|'[^'\n]+'|`[^`\n]+`|\S+)/g

// Gateway routing note for Discord turns (gateway/run_inbound.py::discord_triggering_note).
// Current gateways persist the authored text; this heals rows written before that fix. Only
// the note is model-facing — the `[Replying to: …]` pointer next to it is kept.
const DISCORD_TRIGGERING_NOTE_RE =
  /(^|\n)\[Triggering message id: `[^`\n]*` — use as `message_id` for reply\/react\/pin via the discord tools\.\]\n*/

/**
 * Backend history projection authorizes/sanitizes public commentary before it
 * reaches Desktop. Raw Responses sidecars are used only for final-answer fallback;
 * phase=analysis and raw phase=commentary are never promoted to assistant text.
 */
function codexMessageItemText(message: SessionMessage): { commentary: string[]; reply: string } {
  let items = message.codex_message_items

  const commentary = Array.isArray(message.display_commentary)
    ? message.display_commentary.filter((part): part is string => typeof part === 'string' && Boolean(part.trim()))
    : []

  const replies: string[] = []

  // REST carries SQLite JSON text; RPC history carries the decoded list.
  if (typeof items === 'string') {
    try {
      items = JSON.parse(items)
    } catch {
      return { commentary, reply: '' }
    }
  }

  if (!Array.isArray(items)) {
    return { commentary, reply: '' }
  }

  for (const item of items) {
    if (!item || typeof item !== 'object' || Array.isArray(item)) {
      continue
    }

    const record = item as Record<string, unknown>

    if (record.type !== 'message' || record.role !== 'assistant') {
      continue
    }

    const phase = typeof record.phase === 'string' ? record.phase.trim().toLowerCase() : ''

    if (phase === 'analysis' || phase === 'commentary' || !Array.isArray(record.content)) {
      continue
    }

    const chunks: string[] = []

    for (const part of record.content) {
      if (!part || typeof part !== 'object' || Array.isArray(part)) {
        continue
      }

      const partRecord = part as Record<string, unknown>

      if ((partRecord.type === 'output_text' || partRecord.type === 'text') && typeof partRecord.text === 'string') {
        chunks.push(partRecord.text)
      }
    }

    const text = chunks.join('')

    if (text) {
      replies.push(text)
    }
  }

  return { commentary, reply: replies.join('') }
}

function displayContentForMessage(role: SessionMessage['role'], content: unknown): string {
  const rawText = textFromUnknown(content)

  if (role !== 'user') {
    return rawText
  }

  const textContent = rawText.replace(DISCORD_TRIGGERING_NOTE_RE, '$1')

  // A `/skill` turn is stored expanded (the whole skill body). Current
  // gateways project it to the invocation before it ever reaches us; this is
  // the fallback for an older backend that still ships the raw payload.
  const invocation = skillInvocationText(textContent)

  if (invocation) {
    return invocation
  }

  const marker = textContent.match(ATTACHED_CONTEXT_MARKER_RE)

  if (!marker || marker.index === undefined) {
    return textContent.replace(CONTEXT_WARNINGS_MARKER_RE, '').trim()
  }

  const visibleText = textContent.slice(0, marker.index).replace(CONTEXT_WARNINGS_MARKER_RE, '').trim()
  const attachedContext = textContent.slice(marker.index + marker[0].length)
  const refs = [...new Set(Array.from(attachedContext.matchAll(CONTEXT_REF_RE)).map(match => match[0]))]

  // The prose keeps the `@file:` token the user typed, so it already chips in
  // place. Only hoist a ref the prose is missing — a turn persisted by an older
  // backend that stripped the tokens. Re-listing an inline ref would chip twice.
  const missing = refs.filter(ref => !visibleText.includes(ref))

  return [missing.join('\n'), visibleText].filter(Boolean).join('\n\n') || visibleText
}

function transcriptContent(
  displayKind: SessionMessage['display_kind'],
  role: SessionMessage['role'],
  content: string
): string | null {
  if (displayKind === 'hidden') {
    return null
  }

  return role === 'user' && LEGACY_HEARTBEAT_ROW_RE.test(content.trim()) ? null : content
}

/**
 * Backend-authored transcript notices. The gateway persists these itself and no
 * view "sent" them, so they render as system rows.
 */
const NOTICE_DISPLAY_KINDS = [
  'model_switch',
  'async_delegation_complete',
  'process_complete',
  'auto_continue',
  'personality_switch',
  // Hermes closing a failed turn, not the model speaking.
  'failed_turn'
] as const

function isMachineNotice(displayKind: SessionMessage['display_kind']): boolean {
  return displayKind !== undefined && (NOTICE_DISPLAY_KINDS as readonly string[]).includes(displayKind)
}

// A remote backend older than this app serves display_metadata as raw JSON text,
// and `in` throws on a primitive — which used to fail the whole session resume.
function parseDisplayMetadata(metadata: SessionMessage['display_metadata']): null | Record<string, unknown> {
  let parsed: unknown = metadata

  if (typeof parsed === 'string') {
    try {
      parsed = JSON.parse(parsed)
    } catch {
      return null
    }
  }

  return parsed && typeof parsed === 'object' ? (parsed as Record<string, unknown>) : null
}

// `agent/conversation_loop.py::_failed_turn_display_metadata`: the failed turn's error card,
// kept on its boundary row so a reopened session shows it after the live frame is gone.
function failedTurnError(
  metadata: SessionMessage['display_metadata']
): null | Pick<ChatMessage, 'error' | 'errorSurface'> {
  const parsed = parseDisplayMetadata(metadata)
  const errorSurface = parseErrorSurface(parsed?.error_surface)

  if (!errorSurface) {
    return null
  }

  const error = typeof parsed?.error === 'string' && parsed.error.trim() ? parsed.error : errorSurface.code

  return { error, errorSurface }
}

function timelineTaskCount(metadata: SessionMessage['display_metadata']): number | undefined {
  const count = parseDisplayMetadata(metadata)?.task_count

  return typeof count === 'number' ? count : undefined
}

function timelineDisplayText(metadata: SessionMessage['display_metadata']): string | undefined {
  const text = parseDisplayMetadata(metadata)?.display_text

  return typeof text === 'string' && text.trim() ? text : undefined
}

function messageInterrupted(metadata: SessionMessage['display_metadata']): boolean {
  return parseDisplayMetadata(metadata)?.interrupted === true
}

function messageReactions(metadata: SessionMessage['display_metadata']): MessageReaction[] {
  const reactions = parseDisplayMetadata(metadata)?.reactions

  if (!Array.isArray(reactions)) {
    return []
  }

  return reactions.filter(
    (r): r is MessageReaction => Boolean(r) && typeof r === 'object' && typeof (r as MessageReaction).emoji === 'string'
  )
}

// Only parse producer-owned boundaries, never render the model's task preamble.
// Older backends can persist an unwrapped result rather than an envelope.
function asyncResultBody(content: string): string | undefined {
  let bodies = [content]

  if (content.startsWith('[IMPORTANT: ')) {
    // Background-process completion: one `[IMPORTANT: …]` block per process, a batch header first.
    bodies = content
      .split(/\n\n(?=\[IMPORTANT: )/)
      .map(block => block.replace(/^\[IMPORTANT:\s*/, '').replace(/\]$/, ''))
      .filter(block => !/^\d+ background processes completed\./.test(block))
  } else if (content.startsWith('[ASYNC DELEGATION')) {
    if (content.startsWith('[ASYNC DELEGATION BATCH COMPLETE')) {
      // Task goals can span lines; stopping at a newline leaks the next goal and transcript footer.
      bodies = content.split(/^--- [✓✗⚠] TASK \d+\/\d+(?:: [\s\S]*?)? {2}\(status=[^\n]*\) ---\r?\n/gm).slice(1)
    } else {
      const result = content.match(/^--- (?:RESULT|ERROR) ---\r?\n/m)
      bodies = result ? [content.slice(result.index! + result[0].length)] : []
    }
  }

  return (
    bodies
      .map(body => {
        const output = body.startsWith('Cron job ') ? body.match(/^--- JOB OUTPUT ---\r?\n/m) : null
        const result = output ? body.slice(output.index! + output[0].length) : body

        return result.replace(/\nFull live transcript \(complete tool\/assistant trace\): [^\n]*\n*$/, '').trim()
      })
      .filter(Boolean)
      .join('\n\n') || undefined
  )
}

function timelineDisplayContent(message: SessionMessage, content: string): string {
  if (message.display_kind === 'model_switch') {
    return 'model changed'
  }

  if (message.display_kind === 'auto_continue') {
    return 'resumed interrupted turn'
  }

  if (message.display_kind === 'personality_switch') {
    return 'personality changed'
  }

  if (message.display_kind === 'async_delegation_complete') {
    const count = timelineTaskCount(message.display_metadata)

    return (
      timelineDisplayText(message.display_metadata) ??
      (count === undefined
        ? 'background agent work finished'
        : `${count} background agent${count === 1 ? '' : 's'} finished`)
    )
  }

  if (message.display_kind === 'process_complete') {
    return timelineDisplayText(message.display_metadata) ?? 'background process finished'
  }

  return content
}

export function toChatMessages(messages: SessionMessage[]): ChatMessage[] {
  const result: ChatMessage[] = []
  let pendingToolParts: ChatMessagePart[] = []
  let pendingToolTimestamp: number | undefined
  // Backend rows the pending batch stands for. The fold merges a turn's tool
  // rows into one message, and the store's older-page offset is counted in
  // backend rows, so the folded message has to report how many it covers
  // (see ChatMessage.serverRowSpan).
  let pendingToolRows = 0
  let activeAssistantIndex: null | number = null
  // Todo history is stateful. Only a result from the nearest prior assistant
  // call in this turn may update it; a display-only orphan can still render.
  let nearestAssistant: null | SessionMessage = null

  const pairedTodoResult = (toolMessage: SessionMessage): boolean => {
    const id = toolMessage.tool_call_id

    if (!id || !Array.isArray(nearestAssistant?.tool_calls)) {
      return false
    }

    return nearestAssistant.tool_calls.some((call, index) => {
      const part = toolPartFromStoredCall(call, index)

      if (part.type !== 'tool-call' || part.toolCallId !== id) {
        return false
      }

      if (isTodoToolName(part.toolName)) {
        return true
      }

      const args = part.args as { calls?: unknown }

      return (
        part.toolName === 'tool_call' &&
        Array.isArray(args?.calls) &&
        args.calls.some(inner => inner && typeof inner === 'object' && isTodoToolName(inner.name))
      )
    })
  }

  const clearPendingTools = () => {
    pendingToolParts = []
    pendingToolTimestamp = undefined
    pendingToolRows = 0
  }

  /** Attribute `rows` backend rows to a folded message (absent field means one). */
  const absorbRows = (message: ChatMessage | undefined, rows: number) => {
    if (message && rows > 0) {
      message.serverRowSpan = (message.serverRowSpan ?? 1) + rows
    }
  }

  const earliestTimestamp = (...values: (number | undefined)[]) => {
    const timestamps = values.filter((value): value is number => value !== undefined)

    return timestamps.length ? Math.min(...timestamps) : undefined
  }

  const appendPartsToActiveAssistant = (parts: ChatMessagePart[], timestamp?: number): boolean => {
    if (activeAssistantIndex === null) {
      return false
    }

    const active = result[activeAssistantIndex]

    if (!active || active.role !== 'assistant') {
      activeAssistantIndex = null

      return false
    }

    active.parts = [...active.parts, ...parts]
    active.durableComplete = false
    active.timestamp = earliestTimestamp(active.timestamp, timestamp, ...parts.map(part => part.timestamp))
    absorbRows(active, pendingToolRows)

    return true
  }

  const flushPendingTools = (index: number) => {
    if (!pendingToolParts.length) {
      return
    }

    if (!appendPartsToActiveAssistant(pendingToolParts, pendingToolTimestamp)) {
      result.push({
        id: `${pendingToolTimestamp || Date.now()}-${index}-tools`,
        role: 'assistant',
        parts: pendingToolParts,
        durableComplete: false,
        ...(pendingToolRows > 1 ? { serverRowSpan: pendingToolRows } : {}),
        timestamp: pendingToolTimestamp
      })
      activeAssistantIndex = result.length - 1
    }

    clearPendingTools()
  }

  messages.forEach((message, index) => {
    if (parseMediaGuard(message.display_metadata) ||
        (activeAssistantIndex !== null && result[activeAssistantIndex]?.mediaGuard)) {
      activeAssistantIndex = null
    }

    if (message.role === 'assistant') {
      nearestAssistant = message
    } else if (message.role === 'user' || message.role === 'system') {
      nearestAssistant = null
    }
    if (message.role === 'tool') {
      if (isTodoToolName(message.tool_name) && !pairedTodoResult(message)) {
        pendingToolParts = [...pendingToolParts, storedToolMessagePart(message, index)]
        pendingToolTimestamp ??= message.timestamp
        pendingToolRows += 1

        return
      }

      const updatedPendingToolParts = applyStoredToolResultToParts(pendingToolParts, message)

      if (updatedPendingToolParts) {
        pendingToolParts = updatedPendingToolParts
        pendingToolRows += 1

        return
      }

      if (applyStoredToolResult(result, message)) {
        return
      }

      pendingToolParts = [...pendingToolParts, storedToolMessagePart(message, index)]
      pendingToolTimestamp ??= message.timestamp
      pendingToolRows += 1

      return
    }

    const content =
      message.display_content !== undefined
        ? message.display_content
        : message.content || message.text || message.context || message.name

    const rawDisplayContent = transcriptContent(
      message.display_kind,
      message.role,
      timelineDisplayContent(message, displayContentForMessage(message.role, content))
    )

    const displayRole = isMachineNotice(message.display_kind) ? 'system' : message.role

    // Persisted user turns carry `@image:<path>` directive lines inline in
    // the text (see tui_gateway/server.py's persist-time rewrite). The
    // read-only bubble clamps its body to ~2 lines, and a large inline image
    // thumbnail pushes any caption text below the clamp's visible area — so
    // pull image refs out into `attachmentRefs` (same shape the local
    // optimistic composer already uses) and render them via the dedicated
    // attachments row below the bubble instead. The leading `@file:` block
    // (attached files, large pastes) moves there too, for the same parity.
    const imageRefExtraction = displayRole === 'user' && rawDisplayContent ? extractImageRefs(rawDisplayContent) : null
    const fileRefExtraction = imageRefExtraction ? splitLeadingAttachmentRefs(imageRefExtraction.cleanedText) : null
    const displayContent = fileRefExtraction ? fileRefExtraction.text : rawDisplayContent
    const liftedRefs = [...(fileRefExtraction?.refs ?? []), ...(imageRefExtraction?.refs ?? [])]
    const extractedAttachmentRefs = liftedRefs.length ? liftedRefs : undefined

    const parts: ChatMessagePart[] = []
    const rowId = message.row_id ?? (typeof message.id === 'number' ? message.id : undefined)
    const sourceHasTools = Array.isArray(message.tool_calls) && message.tool_calls.length > 0
    const durableComplete = sourceHasTools ? false : rowId !== undefined ? true : undefined

    const codexText =
      displayRole === 'assistant' && message.display_kind !== 'hidden' ? codexMessageItemText(message) : null

    const commentary = codexText?.commentary ?? []

    const rawReasoning =
      message.reasoning || message.reasoning_content || reasoningTextFromDetails(message.reasoning_details)

    const reasoning = message.display_reasoning !== undefined ? message.display_reasoning : rawReasoning

    if (reasoning && message.role === 'assistant') {
      parts.push(reasoningPart(reasoning, message.timestamp))
    }

    const reply = message.display_content !== undefined ? displayContent : displayContent || codexText?.reply
    // Some providers also persist the joined commentary as canonical content.
    // Keep that authoritative copy once, without treating unrelated final text
    // as a reason to discard the earlier public messages.
    const normalized = (value: string) => renderMediaTags(value).replace(/\s+/g, ' ').trim()

    const commentaryIsReply = Boolean(
      reply && commentary.length && normalized(commentary.join('\n\n')) === normalized(reply)
    )

    if (!commentaryIsReply) {
      parts.push(...commentary.map(text => assistantTextPart(text, message.timestamp)))
    }

    if (reply) {
      parts.push(
        displayRole === 'assistant' ? assistantTextPart(reply, message.timestamp) : textPart(reply, message.timestamp)
      )
    }

    if (message.role === 'assistant' && Array.isArray(message.tool_calls)) {
      parts.push(
        ...message.tool_calls.map((call, callIndex) =>
          toolPartFromStoredCall(call, callIndex, message.timestamp, message.tool_call_labels)
        )
      )
    }

    if (rowId !== undefined) {
      for (const part of parts) {
        if (part.type === 'text') {
          part.sourceRowId = rowId
        }
      }
    }

    if (!parts.length && !extractedAttachmentRefs?.length) {
      if (message.role !== 'assistant') {
        flushPendingTools(index)
        activeAssistantIndex = null
      }

      return
    }

    const isToolOnlyAssistant =
      message.role === 'assistant' && parts.length > 0 && parts.every(part => part.type === 'tool-call')

    if (isToolOnlyAssistant) {
      pendingToolParts = [...pendingToolParts, ...parts]
      pendingToolTimestamp ??= message.timestamp
      pendingToolRows += 1

      return
    }

    let pendingAbsorbedRows = 0

    if (message.role === 'assistant') {
      if (pendingToolParts.length) {
        if (!appendPartsToActiveAssistant(pendingToolParts, message.timestamp ?? pendingToolTimestamp)) {
          parts.unshift(...pendingToolParts)
          pendingAbsorbedRows = pendingToolRows
        }

        clearPendingTools()
      }

      const activeAssistant =
        activeAssistantIndex !== null && result[activeAssistantIndex]?.role === 'assistant'
          ? result[activeAssistantIndex]
          : null

      const currentHasToolCall = parts.some(part => part.type === 'tool-call')
      const activeHasToolCall = Boolean(activeAssistant?.parts.some(part => part.type === 'tool-call'))

      if (activeAssistant && (currentHasToolCall || activeHasToolCall)) {
        activeAssistant.parts = [...activeAssistant.parts, ...parts]
        activeAssistant.durableComplete = durableComplete
        activeAssistant.timestamp = earliestTimestamp(
          activeAssistant.timestamp,
          message.timestamp,
          ...parts.map(part => part.timestamp)
        )
        absorbRows(activeAssistant, 1)

        return
      }
    } else {
      flushPendingTools(index)
    }

    const failure = message.display_kind === 'failed_turn' ? failedTurnError(message.display_metadata) : null

    if (failure) {
      // Stands for no backend row of its own; the boundary row below counts itself.
      result.push({
        id: `${message.timestamp || Date.now()}-${index}-failed-turn-error`,
        role: 'assistant',
        parts: [],
        pending: false,
        serverRowSpan: 0,
        ...failure,
        ...(message.timestamp ? { timestamp: message.timestamp } : {})
      })
    }

    const reactions = messageReactions(message.display_metadata)
    // Gateway resume names the durable row id `row_id`; the REST transcript
    // prefetch ships the same messages.id as a numeric `id`. Either one lets
    // reactions address this exact row later.
    result.push({
      id: `${message.timestamp || Date.now()}-${index}-${displayRole}`,
      role: displayRole,
      parts,
      ...(parseMediaGuard(message.display_metadata) ? { mediaGuard: parseMediaGuard(message.display_metadata) } : {}),
      ...(message.role === 'assistant' && durableComplete !== undefined ? { durableComplete } : {}),
      ...(message.display_kind === 'async_delegation_complete' || message.display_kind === 'process_complete'
        ? { asyncResult: asyncResultBody(displayContentForMessage(message.role, message.content || content)) }
        : {}),
      ...(message.display_kind === 'process_complete' ? { asyncResultKind: 'process' as const } : {}),
      timestamp: earliestTimestamp(message.timestamp, ...parts.map(part => part.timestamp)),
      ...(rowId !== undefined ? { rowId } : {}),
      ...(pendingAbsorbedRows > 0 ? { serverRowSpan: pendingAbsorbedRows + 1 } : {}),
      ...(reactions.length ? { reactions } : {}),
      ...(message.role === 'assistant' && messageInterrupted(message.display_metadata) ? { interrupted: true } : {}),
      ...(extractedAttachmentRefs ? { attachmentRefs: extractedAttachmentRefs } : {})
    })

    activeAssistantIndex = message.role === 'assistant' ? result.length - 1 : null
  })
  flushPendingTools(messages.length)

  const withoutGeneratedImageEchoes = result.map(message =>
    message.role === 'assistant'
      ? { ...message, parts: dedupeRepeatedTextInParts(dedupeGeneratedImageEchoesInParts(message.parts)) }
      : message
  )

  return withUniqueToolCallIds(
    withoutGeneratedImageEchoes.filter(
      m =>
        chatMessageText(m).trim() || m.parts.some(part => part.type !== 'text') || m.attachmentRefs?.length || m.error
    )
  )
}
