import type { MediaGuard } from '@/lib/media-reaction-guard'
import type { ThreadMessageLike } from '@assistant-ui/react'
import { type BillingBlock, type MessageCompletePayload, type PersistedTurn, type ToolLabel } from '@hermes/shared'

import type { ErrorSurface } from '@/lib/error-surface'
import type { ToolResultMetadata } from '@/lib/tool-result-metadata'
import type { MessageReaction, SessionMessage, UsageStats } from '@/types/hermes'

export interface TimelinePartMetadata {
  toolResultMetadata?: ToolResultMetadata
  /** Unix seconds when this visible activity segment began. Fractional values
   * preserve the millisecond precision available on live gateway events. */
  timestamp?: number
  /** Unix seconds when this segment stopped or handed off to the next one. */
  completedAt?: number
  /** A tool call the user stopped or redirected before its result arrived. */
  interrupted?: boolean
  /** Raw streamed text behind a `text` part whose MEDIA tags are already rendered,
   * so the next delta re-renders from the source instead of the render. */
  mediaSource?: string
  /** Stored tool result without a matching assistant call in the loaded page.
   *  Render for history, but never treat it as authoritative Todo state. */
  unpairedStoredToolResult?: boolean
  /** Actual completed tool name when the assistant called a wrapper such as tool_call. */
  storedResultToolName?: string
  /** Durable source occurrence, even when several backend rows share a bubble. */
  sourceRowId?: number
}

export type ChatMessagePart = Exclude<ThreadMessageLike['content'], string>[number] & TimelinePartMetadata

export type ChatMessage = {
  mediaGuard?: MediaGuard
  id: string
  role: SessionMessage['role']
  parts: ChatMessagePart[]
  /** Result body only; the system text remains the compact completion label. */
  asyncResult?: string
  asyncResultKind?: 'process'
  timestamp?: number
  completedAt?: number
  pending?: boolean
  error?: string
  /** Structured layer descriptor for a failed turn (parsed error_surface).
   *  Drives the error card's layer label + actions; absent on older
   *  backends, where the card falls back to generic copy. */
  errorSurface?: ErrorSurface
  branchGroupId?: string
  hidden?: boolean
  /** Sealed mid-turn commentary (`message.interim`) — rendered without the
   *  action footer so only the turn's final reply carries copy/refresh, and
   *  the live view matches rehydration (which merges the turn into one bubble). */
  interim?: boolean
  /** The user stopped this reply before it finished; its text is partial. */
  interrupted?: boolean
  /** Locally recovered output not yet represented by a durable completed reply. */
  recovered?: boolean
  /** Whether hydration reached a final assistant source row, rather than a tool round. */
  durableComplete?: boolean
  /** Exact gateway receipt; whole-turn coverage is never inferred from prose. */
  persistedTurn?: PersistedTurn
  /** Whole-turn wall-clock seconds (message.start → message.complete),
   *  stamped by the desktop when it watched the turn run. Absent for
   *  messages hydrated from history — the backend doesn't persist it. */
  durationS?: number
  /** Composer attachment ref strings (`@file:...`, `@image:...`) sent with this user message. */
  attachmentRefs?: string[]
  /** Durable backend `messages.id`. Absent until the row is persisted. */
  rowId?: number
  /** Backend transcript rows this message represents — the hydration fold
   *  merges a turn's tool rows into the assistant message they belong to, so a
   *  message is not one backend row. The older-page offset (transcript-tail) is
   *  counted in backend rows, so anything that rewinds that offset must convert
   *  through this. Absent means one row. */
  serverRowSpan?: number
  /** Emoji reactions on this message — one per author (see MessageReaction). */
  reactions?: MessageReaction[]
}

export type GatewayEventPayload = {
  /** Unix seconds supplied by tests/newer gateways; the desktop falls back to
   * its local receipt clock when older gateways omit it. */
  timestamp?: number
  text?: string
  rendered?: string
  status?: string
  message?: string
  id?: string
  name?: string
  tool_id?: string
  tool_call_id?: string
  args?: unknown
  arguments?: unknown
  context?: string
  input?: unknown
  labels?: ToolLabel[]
  preview?: string
  result?: unknown
  summary?: string
  error?: string | boolean
  // error — the gateway's machine-readable cause, when it has one (currently
  // "provider_not_configured" from a failed agent init). Absent on older
  // gateways; consumers must fall back to string heuristics.
  code?: string
  // message.complete with status "error" — structured {layer, code, retryable}
  // descriptor naming which stack layer failed (agent/error_surface.py).
  // Absent on older gateways; consumers must fall back to string heuristics.
  error_surface?: unknown
  inline_diff?: string
  duration_s?: number
  todos?: unknown
  revision?: number
  model?: string
  provider?: string
  reasoning_effort?: string
  reasoning_effort_wire?: string
  service_tier?: string
  fast?: boolean
  approval_mode?: string
  yolo?: boolean
  running?: boolean
  turn_started_at?: number | null
  cwd?: string
  branch?: string
  terminal_backend?: string
  credential_warning?: string
  install_warning?: string
  personality?: string
  usage?: Partial<UsageStats>
  // agent.terminal.output — live chunk for a read-only agent terminal tab
  process_id?: string
  chunk?: string
  // clarify.request
  request_id?: string
  question?: string
  // btw.complete / background.complete — id of the side/background task
  task_id?: string
  questions?: unknown
  answers?: Record<string, unknown>
  // connection request (manage_connections MCP targets — inline approval card)
  op_id?: string
  deadline_at?: number
  targets?: unknown
  action?: string
  reason?: string
  // approval server request (dangerous command / execute_code) — session-keyed
  command?: string
  description?: string
  // False when the backend forbids a permanent allow.
  allow_permanent?: boolean
  smart_denied?: boolean
  // secret.request (skill credential capture)
  env_var?: string
  prompt?: string
  // vault.unlock.request (external password-manager unlock)
  backend?: string
  display_name?: string
  /** vault.save_login.request / vault.code.request */
  origin?: string
  site?: string
  hint?: string
  // terminal.read.request / preview.read.request (GUI agent reading the
  // in-app terminal pane or the browser/preview pane)
  start?: number
  count?: number
  // status.update (kind=process → background process completion/watch-match)
  kind?: string
  // pane.reveal (agent focusing a desktop pane via the focus_pane tool)
  pane?: string
  // layout.apply (agent applying a layout preset via the apply_layout tool)
  preset?: string
  // tour.request (tour tool — agent-guided driver.js walkthrough). `action`
  // and `steps` name the tour verb and step list; `surface` picks the app's
  // own DOM vs the preview pane's guest page. tip.show (tip tool — one accent
  // bubble with an arrow, no overlay) adds no fields of its own: it reuses
  // `selector`/`side` here plus `text`/`title`, and carries no request_id
  // because a tip is fire-and-forget.
  surface?: string
  selector?: string
  side?: string
  steps?: unknown
  step_index?: number
  // preview.act.request (drive_preview tool — agent clicking/typing/scrolling in
  // the in-app browser). `action` names the verb and `selector` is shared with
  // tour above; `ref` addresses an element from the last inventory.
  ref?: string
  submit?: boolean
  key?: string
  amount?: number
  to?: string
  max?: number
  // message.reaction (agent reacting via the react_to_message tool) — the
  // durable messages.id, that row's full reaction list after the write, and
  // the row's role so a live (not-yet-round-tripped) message can be matched.
  row_id?: number
  reactions?: MessageReaction[]
  role?: string
  // session.title (live auto-title push) — stored session id + generated title
  session_id?: string
  title?: string
  // session.info — the stored (durable) session id for this runtime session.
  // Lets the desktop app map runtime→stored for background sessions it hasn't
  // opened, so the sidebar working indicator updates without opening the chat.
  stored_session_id?: string
  // moa.reference / moa.aggregating (Mixture of Agents per-model relay)
  label?: string
  index?: number
  aggregator?: string
  // moa.progress / moa.phase (Mixture of Agents fan-out progress relay)
  refs_done?: number
  refs_total?: number
  phase?: string
  // message.complete — signals the final text was already previewed via
  // interim_assistant_callback, so the UI can settle instead of duplicating.
  response_previewed?: boolean
  // message.complete — a transform_llm_output hook rewrote the final text after streaming;
  // it authoritatively replaces the current turn's streamed text even without a prefix match.
  response_transformed?: MessageCompletePayload['response_transformed']
  // message.complete — `text` is a response this turn already delivered: it adds no text.
  response_reused?: MessageCompletePayload['response_reused']
  persisted_turn?: PersistedTurn | null
  // message.complete — history-commit note the gateway surfaced instead of dropping.
  warning?: string
  // message.complete with status "error" — `text` is streamed partial output
  // (keep it visible), not the error string.
  partial?: boolean
  // message.complete with status "error" — the failed turn was retained
  // backend-side and will replay through session.resume's inflight payload.
  recoverable?: boolean
  // Structured billing wall forwarded on message.complete when a turn fails
  // with FailoverReason.billing (shape mirrors @hermes/shared BillingBlock).
  billing?: BillingBlock
  failure_reason?: string
}
