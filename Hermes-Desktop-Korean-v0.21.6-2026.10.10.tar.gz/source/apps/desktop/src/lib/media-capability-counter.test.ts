import { describe, expect, it } from 'vitest'
import { MEDIA_CAPABILITY_COUNTER_KEY as key, reserveMediaCapabilityRevision } from './media-capability-counter'

describe('media capability revision across renderer reloads', () => {
  it('reserves beyond prior renderer revisions without a wall clock', () => {
    const values = new Map<string, string>()
    const storage = { getItem: (k: string) => values.get(k) ?? null, setItem: (k: string, v: string) => { values.set(k, v) } }
    expect(reserveMediaCapabilityRevision(storage)).toBe(1)
    expect(reserveMediaCapabilityRevision(storage, 1)).toBe(2)
    expect(reserveMediaCapabilityRevision(storage)).toBe(3)
    expect(reserveMediaCapabilityRevision(storage, 8)).toBe(9)
  })
  it('rejects corrupt, overflowing, denied or lost writes', () => {
    for (const text of ['bad', '-1', '1.5', String(Number.MAX_SAFE_INTEGER)]) {
      expect(reserveMediaCapabilityRevision({getItem: () => text, setItem: () => {}})).toBeNull()
    }
    expect(reserveMediaCapabilityRevision({getItem: () => null, setItem: () => {throw new Error('denied')}})).toBeNull()
    expect(reserveMediaCapabilityRevision({getItem: () => null, setItem: () => {}})).toBeNull()
    expect(key).toBe('hermes_media_capability_revision_v1')
  })
})
