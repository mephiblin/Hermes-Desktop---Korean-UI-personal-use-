/** Profile-local monotonic revision reservation. Unknown storage fails closed. */
export const MEDIA_CAPABILITY_COUNTER_KEY = 'hermes_media_capability_revision_v1'
export interface CounterStorage {
  getItem(key: string): string | null
  setItem(key: string, value: string): void
}

export function reserveMediaCapabilityRevision(storage: CounterStorage, current = 0): number | null {
  try {
    const text = storage.getItem(MEDIA_CAPABILITY_COUNTER_KEY)
    const stored = text === null ? 0 : /^\d+$/.test(text) ? Number(text) : NaN
    if (!Number.isSafeInteger(stored) || stored < 0 || !Number.isSafeInteger(current) || current < 0) return null
    const next = Math.max(stored, current) + 1
    if (!Number.isSafeInteger(next)) return null
    storage.setItem(MEDIA_CAPABILITY_COUNTER_KEY, String(next))
    if (storage.getItem(MEDIA_CAPABILITY_COUNTER_KEY) !== String(next)) return null
    return next
  } catch {
    return null
  }
}
