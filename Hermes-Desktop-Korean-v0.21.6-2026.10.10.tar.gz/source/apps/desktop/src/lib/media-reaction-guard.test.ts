import { describe, expect, it } from 'vitest'

import { $autoSpeakReplies } from '@/store/voice-prefs'

import {
  acknowledgeMediaPresentation,
  bindMediaLane,
  fenceMediaLane,
  mediaPresentationAllowed,
  nativeMediaCapabilities,
  updateMediaVoiceState,
  type MediaBinding,
  type MediaGuard
} from './media-reaction-guard'

function fixture(chatId: string) {
  const binding: MediaBinding = {
    device_id: 'device', chat_id: chatId, viewer_id: chatId, pipeline_id: 'pipeline',
    media_session_id: 'media', content_id: 'content', source_generation: 0,
    delivery_epoch: 0, process_owner_id: 'owner'
  }
  updateMediaVoiceState(chatId, false)
  bindMediaLane(binding)
  const guard: MediaGuard = {
    version: 1, intent_id: chatId, commit_id: chatId, binding, epoch: 0,
    capability_revision: nativeMediaCapabilities(chatId).capability_revision
  }
  return { binding, guard }
}

describe('native media publication fence', () => {
  it('resolves only an explicit runtime alias and preserves unknown otherwise', () => {
    $autoSpeakReplies.set(false)
    updateMediaVoiceState('runtime-alias', false)
    expect(nativeMediaCapabilities('durable-alias').voice_conversation).toBeNull()
    expect(nativeMediaCapabilities('durable-alias', 'runtime-alias').text_only_verified).toBe(true)
    updateMediaVoiceState('runtime-alias', true)
    expect(nativeMediaCapabilities('durable-alias', 'runtime-alias').output_channel).toBe('voice')
    expect(nativeMediaCapabilities('other-durable', 'other-runtime').voice_conversation).toBeNull()
  })

  it('leaves ordinary chat unaffected and rejects unknown media bindings', () => {
    expect(mediaPresentationAllowed(undefined)).toBe(true)
    const { guard } = fixture('unknown-test')
    expect(mediaPresentationAllowed({ ...guard, binding: { ...guard.binding, viewer_id: 'absent' } })).toBe(false)
  })

  it('suppresses 100 late commits immediately after the local fence', () => {
    for (let index = 0; index < 100; index++) {
      const { binding, guard } = fixture(`race-${index}`)
      expect(mediaPresentationAllowed(guard)).toBe(true)
      fenceMediaLane(binding)
      expect(mediaPresentationAllowed(guard)).toBe(false)
    }
  })

  it('keeps already displayed history but does not let it start TTS after cancellation', () => {
    const { binding, guard } = fixture('displayed-test')
    acknowledgeMediaPresentation(guard, false)
    fenceMediaLane(binding)
    expect(mediaPresentationAllowed(guard)).toBe(true)
    expect(mediaPresentationAllowed(guard, false)).toBe(false)
  })

  it('reads the real auto-speak atom and invalidates when it changes', () => {
    $autoSpeakReplies.set(false)
    const { guard } = fixture('tts-test')
    expect(nativeMediaCapabilities('tts-test').text_only_verified).toBe(true)
    $autoSpeakReplies.set(true)
    expect(nativeMediaCapabilities('tts-test').text_only_verified).toBe(false)
    expect(mediaPresentationAllowed(guard, false)).toBe(false)
    $autoSpeakReplies.set(false)
  })

  it('does not call an unknown voice conversation text-only', () => {
    expect(nativeMediaCapabilities('not-mounted').text_only_verified).toBe(false)
    expect(nativeMediaCapabilities('not-mounted').output_channel).toBe('unknown')
  })
})
