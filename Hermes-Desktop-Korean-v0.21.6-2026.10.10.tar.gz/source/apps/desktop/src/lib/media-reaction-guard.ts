import { atom } from 'nanostores'

import { $autoSpeakReplies } from '@/store/voice-prefs'
import { reserveMediaCapabilityRevision } from './media-capability-counter'

export interface MediaBinding {
  device_id: string
  chat_id: string
  viewer_id: string
  pipeline_id: string
  media_session_id: string
  content_id: string
  source_generation: number
  delivery_epoch: number
  process_owner_id: string
}

export interface MediaGuard {
  version: 1
  intent_id: string
  commit_id: string
  binding: MediaBinding
  epoch: number
  capability_revision: number
  presentation?: string
}

interface Lane {
  binding: MediaBinding
  active: boolean
  receipt: number
  acknowledge?: (guard: MediaGuard, suppressed: boolean, sequence: number) => void
}

export const $mediaGuardRevision = atom(0)
const lanes = new Map<string, Lane>()
const voice = new Map<string, boolean>()
const displayed = new Set<string>()
const messageGuards = new Map<string, MediaGuard>()
let sequence = 0
let capabilityRevision = 0
let durableCapabilityRevision = false
function advanceCapabilityRevision() {
  let next: number | null = null
  try { next = reserveMediaCapabilityRevision(localStorage, capabilityRevision) } catch { /* unavailable */ }
  durableCapabilityRevision = next !== null
  capabilityRevision = next ?? capabilityRevision + 1
}
advanceCapabilityRevision()
let autoSpeak = $autoSpeakReplies.get()

function key(binding: MediaBinding) {
  return `${binding.device_id}:${binding.viewer_id}`
}

function changed() {
  $mediaGuardRevision.set($mediaGuardRevision.get() + 1)
}

function invalidateLane(lane: Lane) {
  lane.binding = { ...lane.binding, delivery_epoch: lane.binding.delivery_epoch + 1 }
  lane.active = false
}

$autoSpeakReplies.listen(enabled => {
  if (enabled === autoSpeak) return
  autoSpeak = enabled
  advanceCapabilityRevision()
  lanes.forEach(invalidateLane)
  changed()
})

export function updateMediaVoiceState(chatId: string | null | undefined, active: boolean) {
  if (!chatId || voice.get(chatId) === active) return
  voice.set(chatId, active)
  advanceCapabilityRevision()
  lanes.forEach(lane => {
    if (lane.binding.chat_id === chatId) invalidateLane(lane)
  })
  changed()
}

export function nativeMediaCapabilities(chatId: string, runtimeId?: string | null) {
  const voiceId = voice.has(chatId) ? chatId : runtimeId && voice.has(runtimeId) ? runtimeId : chatId
  const known = voice.has(voiceId)
  const audible = autoSpeak || voice.get(voiceId) === true
  return {
    renderer_guard_version: durableCapabilityRevision ? 1 : 0,
    capability_revision: capabilityRevision,
    auto_tts: autoSpeak,
    voice_conversation: known ? voice.get(voiceId)! : null,
    output_channel: audible ? 'voice' : known ? 'text' : 'unknown',
    text_only_verified: durableCapabilityRevision && known && !audible,
    heartbeat_valid_ms: 10_000
  }
}

export function bindMediaLane(
  binding: MediaBinding,
  acknowledge?: Lane['acknowledge'],
  active = true
) {
  const previous = lanes.get(key(binding))
  if (previous && binding.delivery_epoch < previous.binding.delivery_epoch) {
    throw new Error('Stale media binding')
  }
  lanes.set(key(binding), { binding: { ...binding }, active, receipt: performance.now(), acknowledge })
  changed()
  return nativeMediaCapabilities(binding.chat_id)
}

export function heartbeatMediaLane(binding: MediaBinding) {
  const lane = lanes.get(key(binding))
  if (!lane || !sameBinding(lane.binding, binding)) return null
  lane.receipt = performance.now()
  return { ...nativeMediaCapabilities(binding.chat_id), epoch: lane.binding.delivery_epoch, active: lane.active }
}

export function fenceMediaLane(binding: MediaBinding) {
  const lane = lanes.get(key(binding))
  if (!lane) return binding.delivery_epoch + 1
  if (!lane.active) return lane.binding.delivery_epoch
  invalidateLane(lane)
  changed()
  return lane.binding.delivery_epoch
}

function sameBinding(left: MediaBinding, right: MediaBinding) {
  if (!left || typeof left !== 'object' || !right || typeof right !== 'object') return false
  return Object.keys(left).every(field => left[field as keyof MediaBinding] === right[field as keyof MediaBinding])
}

export function mediaGuardsEquivalent(left: MediaGuard | undefined, right: MediaGuard | undefined) {
  if (left === right) return true
  if (!left || !right) return false
  return left.version === right.version && left.intent_id === right.intent_id && left.commit_id === right.commit_id &&
    left.epoch === right.epoch && left.capability_revision === right.capability_revision &&
    left.presentation === right.presentation && sameBinding(left.binding, right.binding)
}

export function parseMediaGuard(metadata: unknown): MediaGuard | undefined {
  let value = metadata
  if (typeof value === 'string') {
    try { value = JSON.parse(value) } catch { return undefined }
  }
  if (!value || typeof value !== 'object') return undefined
  const candidate = (value as Record<string, unknown>).media_guard
  if (!('media_guard' in value)) return undefined
  if (!candidate || typeof candidate !== 'object') return { version: 0 } as unknown as MediaGuard
  // An invalid media envelope is still guarded and will fail closed below.
  return candidate as MediaGuard
}

export function mediaPresentationAllowed(guard: MediaGuard | undefined, allowPreviouslyDisplayed = true) {
  if (!guard) return true
  if (guard.version !== 1 || !guard.binding || !guard.commit_id || !guard.intent_id) return false
  if (allowPreviouslyDisplayed && (displayed.has(guard.commit_id) || guard.presentation === 'displayed')) return true
  const lane = lanes.get(key(guard.binding))
  return Boolean(lane?.active && performance.now() - lane.receipt < 10_000 &&
    sameBinding(lane.binding, guard.binding) && guard.epoch === lane.binding.delivery_epoch &&
    guard.capability_revision === capabilityRevision)
}

export function registerMediaMessage(id: string, guard: MediaGuard | undefined) {
  if (guard) messageGuards.set(id, guard)
}

export function mediaSpeechAllowedForMessage(id: string | null | undefined) {
  return !id || mediaPresentationAllowed(messageGuards.get(id), false)
}

export function acknowledgeMediaPresentation(guard: MediaGuard | undefined, suppressed: boolean) {
  if (!guard?.binding || !guard.commit_id) return
  const lane = lanes.get(key(guard.binding))
  if (!lane) return
  if (!suppressed) {
    if (!mediaPresentationAllowed(guard, false)) return
    if (displayed.has(guard.commit_id)) return
    displayed.add(guard.commit_id)
  }
  lane.acknowledge?.(guard, suppressed, ++sequence)
}

export const mediaReactionHost = {
  capabilities: nativeMediaCapabilities,
  bind: bindMediaLane,
  heartbeat: heartbeatMediaLane,
  invalidate: fenceMediaLane,
  subscribe: $mediaGuardRevision.subscribe
}
