import { afterEach, describe, expect, it } from 'vitest'

import {
  dispatchVoiceTranscript,
  registerVoiceTranscriptInterceptor,
  type VoiceTranscriptInterceptor
} from './voice-transcript'

describe('Desktop voice transcript interception', () => {
  const disposers: Array<() => void> = []

  afterEach(() => {
    disposers.splice(0).forEach(dispose => dispose())
  })

  it('sends the final transcript and exact chat id to enabled interceptors', async () => {
    const events: unknown[] = []
    disposers.push(registerVoiceTranscriptInterceptor(event => {
      events.push(event)

      return 'handled'
    }))

    const result = await dispatchVoiceTranscript({ text: '카메라 멈춰', chatId: 'chat-42' })

    expect(result).toBe('handled')
    expect(events).toEqual([{ text: '카메라 멈춰', chatId: 'chat-42' }])
  })

  it('stops at the first consumer and leaves normal transcripts on the standard submit path', async () => {
    const events: string[] = []

    const first: VoiceTranscriptInterceptor = () => {
      events.push('first')

      return 'stop'
    }

    const second: VoiceTranscriptInterceptor = () => {
      events.push('second')

      return 'handled'
    }

    disposers.push(registerVoiceTranscriptInterceptor(first))
    disposers.push(registerVoiceTranscriptInterceptor(second))

    expect(await dispatchVoiceTranscript({ text: '정지', chatId: null })).toBe('stop')
    expect(events).toEqual(['first'])

    disposers.splice(0).forEach(dispose => dispose())
    expect(await dispatchVoiceTranscript({ text: '오늘 날씨 어때?', chatId: 'chat-42' })).toBe('continue')
  })

  it('lets voice continue to Hermes if a plugin interceptor throws', async () => {
    disposers.push(registerVoiceTranscriptInterceptor(() => { throw new Error('offline') }))
    expect(await dispatchVoiceTranscript({ text: '그만', chatId: 'chat-42' })).toBe('continue')
  })
})
