export interface VoiceTranscriptEvent {
  text: string
  /** Runtime Desktop chat/session id; null when the composer has no session yet. */
  chatId: string | null
}

export type VoiceTranscriptDisposition = 'continue' | 'handled' | 'stop'
export type VoiceTranscriptInterceptor = (
  event: VoiceTranscriptEvent
) => VoiceTranscriptDisposition | Promise<VoiceTranscriptDisposition>

const interceptors = new Set<VoiceTranscriptInterceptor>()

export const registerVoiceTranscriptInterceptor = (handler: VoiceTranscriptInterceptor): (() => void) => {
  interceptors.add(handler)

  return () => interceptors.delete(handler)
}

export const dispatchVoiceTranscript = async (
  event: VoiceTranscriptEvent
): Promise<VoiceTranscriptDisposition> => {
  for (const handler of [...interceptors]) {
    try {
      const disposition = await handler(event)

      if (disposition !== 'continue') {return disposition}
    } catch {
      // An extension failure cannot prevent an ordinary voice turn from reaching Hermes.
    }
  }

  return 'continue'
}
