import { LOCALE_ENDONYMS } from '@hermes/shared/i18n'

import { normalize } from '@/lib/text'

import type { Locale } from './types'

export const DEFAULT_LOCALE: Locale = 'en'

export const LOCALE_OPTIONS = [
  {
    id: 'en',
    name: LOCALE_ENDONYMS.en,
    englishName: 'English',
    configValue: 'en'
  },
  {
    id: 'zh',
    name: LOCALE_ENDONYMS.zh,
    englishName: 'Simplified Chinese',
    configValue: 'zh'
  },
  {
    id: 'zh-hant',
    name: LOCALE_ENDONYMS['zh-hant'],
    englishName: 'Traditional Chinese',
    configValue: 'zh-hant'
  },
  {
    id: 'ja',
    name: LOCALE_ENDONYMS.ja,
    englishName: 'Japanese',
    configValue: 'ja'
  },
  {
    id: 'ko',
    name: '한국어',
    englishName: 'Korean',
    configValue: 'ko'
  },
  {
    id: 'ar',
    name: LOCALE_ENDONYMS.ar,
    englishName: 'Arabic',
    configValue: 'ar'
  },
  {
    id: 'ru',
    name: LOCALE_ENDONYMS.ru,
    englishName: 'Russian',
    configValue: 'ru'
  },
  {
    id: 'fr',
    name: LOCALE_ENDONYMS.fr,
    englishName: 'French',
    configValue: 'fr'
  },
  {
    id: 'de',
    name: LOCALE_ENDONYMS.de,
    englishName: 'German',
    configValue: 'de'
  },
  {
    id: 'es',
    name: LOCALE_ENDONYMS.es,
    englishName: 'Spanish',
    configValue: 'es'
  }
] as const satisfies readonly { configValue: string; englishName: string; id: Locale; name: string }[]

// `name` is the endonym (native name) shown in the picker so users recognize
// their language regardless of the current UI language. No country flags:
// languages are not countries. `englishName` is search-only (not shown) so an
// English speaker can type "japanese"/"traditional" to filter the list.
export const LOCALE_META: Record<Locale, { name: string; englishName: string }> = Object.fromEntries(
  LOCALE_OPTIONS.map(locale => [locale.id, { name: locale.name, englishName: locale.englishName }])
) as Record<Locale, { name: string; englishName: string }>

const LOCALE_ALIASES: Record<string, Locale> = {
  en: 'en',
  'en-us': 'en',
  en_us: 'en',
  zh: 'zh',
  'zh-cn': 'zh',
  zh_cn: 'zh',
  'zh-hans': 'zh',
  zh_hans: 'zh',
  'zh-hans-cn': 'zh',
  zh_hans_cn: 'zh',
  'zh-tw': 'zh-hant',
  zh_tw: 'zh-hant',
  'zh-hk': 'zh-hant',
  zh_hk: 'zh-hant',
  'zh-mo': 'zh-hant',
  zh_mo: 'zh-hant',
  'zh-hant': 'zh-hant',
  zh_hant: 'zh-hant',
  'zh-hant-tw': 'zh-hant',
  zh_hant_tw: 'zh-hant',
  'zh-hant-hk': 'zh-hant',
  zh_hant_hk: 'zh-hant',
  ja: 'ja',
  'ja-jp': 'ja',
  ja_jp: 'ja',
  ko: 'ko',
  'ko-kr': 'ko',
  ko_kr: 'ko',
  korean: 'ko',
  한국어: 'ko',
  ar: 'ar',
  'ar-sa': 'ar',
  ar_sa: 'ar',
  'ar-ae': 'ar',
  ar_ae: 'ar',
  'ar-eg': 'ar',
  ar_eg: 'ar',
  arabic: 'ar',
  العربية: 'ar',
  ru: 'ru',
  'ru-ru': 'ru',
  ru_ru: 'ru',
  'ru-by': 'ru',
  'ru-kz': 'ru',
  russian: 'ru',
  'russian-russian': 'ru',
  русский: 'ru',
  руский: 'ru',
  fr: 'fr',
  'fr-fr': 'fr',
  fr_fr: 'fr',
  'fr-be': 'fr',
  fr_be: 'fr',
  'fr-ca': 'fr',
  fr_ca: 'fr',
  'fr-ch': 'fr',
  fr_ch: 'fr',
  french: 'fr',
  français: 'fr',
  francais: 'fr',
  de: 'de',
  'de-de': 'de',
  de_de: 'de',
  'de-at': 'de',
  de_at: 'de',
  'de-ch': 'de',
  de_ch: 'de',
  german: 'de',
  deutsch: 'de',
  es: 'es',
  'es-es': 'es',
  es_es: 'es',
  'es-mx': 'es',
  es_mx: 'es',
  'es-ar': 'es',
  es_ar: 'es',
  'es-419': 'es',
  es_419: 'es',
  spanish: 'es',
  español: 'es',
  espanol: 'es'
}

export function isLocale(value: unknown): value is Locale {
  return typeof value === 'string' && LOCALE_OPTIONS.some(locale => locale.id === value)
}

export function normalizeLocale(value: unknown): Locale {
  if (typeof value !== 'string') {
    return DEFAULT_LOCALE
  }

  return LOCALE_ALIASES[normalize(value)] ?? DEFAULT_LOCALE
}

export function isSupportedLocaleValue(value: unknown): boolean {
  return typeof value === 'string' && LOCALE_ALIASES[normalize(value)] != null
}

/** OS tags can include regions absent from the picker aliases, such as ru-UA. */
export function osPreferredLocale(tag: string | null | undefined): Locale | null {
  if (!tag) {
    return null
  }

  const exact = LOCALE_ALIASES[normalize(tag)]

  if (exact) {
    return exact
  }

  const base = tag.split(/[-_]/)[0]

  return (base && LOCALE_ALIASES[normalize(base)]) || null
}

/** An explicit choice must win even when it differs from the OS language. */
export function resolveInitialLocale(saved: string | null | undefined, osLocale: string | null | undefined): Locale {
  if (isSupportedLocaleValue(saved)) {
    return normalizeLocale(saved)
  }

  return osPreferredLocale(osLocale) ?? DEFAULT_LOCALE
}

export function localeConfigValue(locale: Locale): string {
  return LOCALE_OPTIONS.find(item => item.id === locale)?.configValue ?? DEFAULT_LOCALE
}
